# Median Browser 1.4.0

Median Browser 是面向 Android 8.0 及以上系统的轻量 WebView 浏览器。本仓库提供可审计源码、Gradle 构建、Google Play AAB 输出和 GitHub Release 自动化。

> 当前状态：**Release Candidate**。源码已完成静态安全加固，但仍必须经过 GitHub Actions、真机矩阵、Google Play 预发布报告和封闭测试后，才能标记为稳定版。

## 主要能力

- 多标签、标签冻结、会话恢复、书签、历史、站点设置与离线 MHTML。
- 广告过滤订阅、元素隐藏、跟踪参数清理。
- 用户脚本、权限声明、菜单命令和受限 GM 网络请求。
- 独立进程隐私窗口；无法可靠隔离时拒绝伪无痕降级。
- Android Keystore 密码库与密码加密完整备份。
- 分段下载、断点续传、暂停、重试、通知控制和下载中心。
- 阅读模式、系统朗读、翻译、页内查找、桌面模式和媒体发现。
- 性能、标准和低功耗三档资源调度。

## 1.4.0 安全与发布加固

- 高权限用户脚本改为最小权限：缺少 `@grant` 时不开放原生能力。
- 在支持的 System WebView 上使用 document-start 注入；不支持可靠注入时关闭高权限脚本能力，而不是不安全降级。
- 原生脚本桥接使用每个 WebView 的随机令牌、当前来源和脚本匹配范围复核；菜单回调不再暴露在网页全局对象中。
- 用户脚本跨域请求逐跳验证 `@connect`、拒绝 HTTPS 降级、限制响应体，并阻止远程网页借脚本访问本机/私网地址。
- 下载和订阅请求手动处理重定向；跨源重定向不转发 Cookie、Authorization 等凭据。
- 离线页面关闭 JavaScript 和网络访问，并仅在离线场景临时允许受控 `content://` 读取。
- Android 15+ 前台下载超时会保存并暂停任务，避免系统超时崩溃。
- 发布密钥仅从环境变量读取；构建脚本不会自动生成弱口令证书。
- 添加 Android App Bundle、R8、Lint、单元测试、静态安全检查、Dependabot 和 GitHub Actions。

## 本地构建

要求：JDK 17、Android SDK Platform 36、Build Tools，以及 Gradle 8.13。Android Studio 可直接打开本项目。

```bash
./tools/static_checks.sh
./build.sh
```

正式签名 APK 与 AAB：

```bash
export MEDIAN_KEYSTORE=/absolute/path/release-key.p12
export MEDIAN_STOREPASS='...'
export MEDIAN_KEY_ALIAS='...'
export MEDIAN_KEYPASS='...'
./build.sh --release
```

输出目录：

```text
app/build/outputs/apk/release/
app/build/outputs/bundle/release/
```

仓库不包含发布密钥。`./gradlew` 会优先使用标准 Wrapper JAR 或系统 Gradle；两者均不存在时，会从 Gradle 官方地址下载 Gradle 8.13，并在解压前校验官方 SHA-256。Windows 可使用 `gradlew.bat`。

## 发布前必须完成

按顺序执行 [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md)。本轮源码改动与剩余风险见 [PATCH_REPORT.md](PATCH_REPORT.md)，数据安全申报参考 [PLAY_DATA_SAFETY.md](PLAY_DATA_SAFETY.md)，隐私政策模板见 [PRIVACY_POLICY.md](PRIVACY_POLICY.md)，与 Via 的可量化验收门槛见 [COMPETITIVE_READINESS.md](COMPETITIVE_READINESS.md)。

## 安全边界

Median 使用设备上的 Android System WebView，因此网页渲染、编解码器和部分兼容性取决于用户设备的 WebView 版本。用户脚本是第三方代码，不能等同于普通网页脚本；只应安装可信来源的脚本。详细威胁模型和漏洞报告流程见 [SECURITY.md](SECURITY.md)。

## 许可

当前源码默认保留全部权利，见 [LICENSE](LICENSE)。在公开接受第三方贡献前，应明确选择开源许可证和贡献者协议。

## 500 KB compatibility build

The production source vendors a focused AndroidX WebKit-compatible slice for
`DOCUMENT_START_SCRIPT` rather than packaging AndroidX's unrelated APIs and
transitive runtimes. This keeps the AndroidX call shape used by the browser and
the Chromium support-library boundary protocol while preserving a strict KB
size budget.

A deterministic signed APK can be built with `tools/build_500kb_apk.sh` after
setting `ANDROID_SDK_ROOT`, `MEDIAN_KEYSTORE`, `MEDIAN_STOREPASS`,
`MEDIAN_KEY_ALIAS`, and optionally `MEDIAN_KEYPASS`. The script reports whether the signed APK stays within the preferred 500 KiB
distribution target. Exceeding the target emits a warning so developers can inspect the
size regression without confusing it with an application build or runtime failure. The normal Gradle build remains available for
Android Studio, CI, APK, and AAB workflows.
