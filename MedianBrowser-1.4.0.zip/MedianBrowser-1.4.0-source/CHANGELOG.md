## 1.4.0
- 首次启动显示一次官方渠道提示；同一信息可在“浏览器设置 → 关于 Median”再次查看。

- 500 KB 定位修正为“兼容性预算”，不再追求 180 KB 极限数字。
- WebView 兼容层新增提供方版本缓存失效、异常分类、OEM 旧特征别名与 UI 线程检查。
- 增加严格来源规则验证；不支持安全 document-start 时继续默认拒绝高权限脚本。
- 关于页新增 WebView 兼容诊断、复制报告和无网络 document-start 顺序自测。
- 500 KiB 仅作为发行目标提示，超过时输出告警而不是把正常构建标记为失败。

# Changelog

## 1.4.0 500 KB RC1

- 将用户脚本 document-start 路径改为聚焦版 AndroidX WebKit 兼容源码，保留 `WebViewCompat`、`WebViewFeature` 与 `ScriptHandler` API 形状。
- 按 AndroidX/Chromium support-library boundary 协议调用 System WebView，不打包无关 WebKit API、AndroidX Core、Lifecycle、VersionedParcelable 或 Kotlin 运行时。
- WebView provider 更新后按包名与版本重新建立兼容快照；不支持时继续 fail closed。
- 增加可重复的 `tools/build_500kb_apk.sh`，构建后报告 500 KiB 发行目标；超过目标只告警，不制造与运行无关的构建失败。
- versionCode 更新为 42，versionName 更新为 `1.4.0`。

## 1.4.0 release candidate

- 建立标准 Gradle/Android App Bundle/R8/Lint/JUnit/GitHub Actions 发布工程，目标 API 36。
- 发布签名改为环境变量注入，删除自动生成弱口令开发证书的路径。
- 用户脚本权限默认拒绝，增加 document-start 安全桥接、来源与权限复核、隐藏菜单回调和旧 WebView 安全降级。
- 用户脚本网络请求逐跳执行 `@connect`、协议、私网和响应体限制，阻止重定向绕过及凭据泄露。
- 下载器与过滤订阅改为手动重定向；跨源时剥离 Cookie 与认证头。
- 分段与断点续传验证 `Content-Range`，下载文件名清除控制字符和双向文本伪装字符。
- 摄像头、麦克风和定位权限绑定完整 HTTPS 来源，授权期间切页或端口变化会自动失效。
- 普通与隐私地址输入、备份导入统一拒绝畸形或带 URL 凭据的网络地址。
- 离线页面关闭 JavaScript 与网络访问，常规网页关闭 content 访问。
- 隐私窗口在无法建立独立 WebView 数据目录时直接拒绝启动。
- 增加 Android 15+ 前台下载超时安全暂停。
- 增加自适应图标、边到边窗口适配、动态版本显示和应用内隐私说明。
- 增加隐私、数据安全、发布、竞争验收、安全报告和第三方声明文档。

## 1.3.5 omni preview

- 移除地址栏右侧独立下载按钮，恢复更完整的地址栏空间。
- 下载中心保留在右下角“三个点”浏览器主菜单中，作为一级入口。
- 下载中心仍由独立 `DownloadCenterActivity` 承载，不属于页面工具，也不依赖当前网页。
- 版本号更新为 `1.3.5-omni-preview`，versionCode 更新为 38。

## 1.3.4 omni preview

- 从“页面工具”中移除旧的下载中心入口。
- 在浏览器主菜单增加一级“下载中心”入口。
- 保留地址栏独立下载按钮，下载中心继续由单独 Activity 承载。
