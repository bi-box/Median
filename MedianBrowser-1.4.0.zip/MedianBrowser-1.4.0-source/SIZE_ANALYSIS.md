# APK size analysis

## Measured packages

| Version | APK size | DEX raw size | DEX stored size | DEX method |
|---|---:|---:|---:|---|
| 1.0.0 | 156,204 B | 321,548 B | 141,991 B | Deflate |
| 1.3.2 | 440,963 B | 434,728 B | 434,728 B | Stored / uncompressed |
| 1.3.3 | 184,936 B | 411,696 B | 178,716 B | Deflate |
| 1.4.0 KB RC1 | 184,958 B | 350,400 B | 170,831 B | Deflate + R8 |
| 1.4.0 500 KB RC1 | 184,958 B | 352,776 B | approximately 170 KB | Deflate + R8 |

No README, source archive, native library, advertising SDK, analytics SDK, or
full AndroidX/Kotlin runtime is included in the APK.

## 500 KB compatibility strategy

The browser keeps the AndroidX WebKit public call shape used by Median:

- `androidx.webkit.WebViewFeature`
- `androidx.webkit.WebViewCompat`
- `androidx.webkit.ScriptHandler`

It vendors only the focused source needed for `DOCUMENT_START_SCRIPT:1` and the
Chromium support-library boundary protocol. Unrelated WebKit APIs, AndroidX
Core, Lifecycle, VersionedParcelable, Kotlin runtime, notification resources,
and compatibility widgets are not packaged.

The final build retains release-mode R8 optimization, minification, a single
compressed DEX, compact resources, sparse resource encoding, no native
libraries, and APK Signature Scheme v2/v3. `tools/build_500kb_apk.sh` rejects a
signed APK larger than 512,000 bytes.

The measured APK is test-signed and uses a separate package ID. Production
Google Play artifacts must use the permanent upload key or Play App Signing and
must be revalidated after the final AAB is generated.
