# Upgrade notes — 1.4.0 500 KB RC1

- applicationId 保持 `com.xinyv.median`，现有本地数据应按 Android 正常升级路径保留。
- versionCode 从 38 升为 42，versionName 改为 `1.4.0`。
- 高权限用户脚本现在要求明确的 `@grant`；旧脚本若依赖隐式 GM 权限，需要补充权限声明。
- document-start 通过聚焦版 AndroidX-compatible facade 调用 System WebView boundary；不支持该能力的旧 WebView 仍会 fail closed，仅运行无原生权限脚本。建议用户更新 Android System WebView。
- 跨域用户脚本请求现在逐跳检查 `@connect`，并拒绝远程页面访问本机或私网目标；依赖宽松重定向的脚本可能需要调整。
- Android 8/9 的系统 DownloadManager 回退路径不再附带网站 Cookie，以避免重定向泄露登录凭据；需要登录态的下载应在 Android 10+ 使用内置下载器。
- 发布构建不再自动生成开发证书。必须显式提供四个 `MEDIAN_*` 签名环境变量。
