package com.xinyv.median;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;

final class DeviceProfile {
    final int sdk;
    final int memoryClassMb;
    final boolean lowRam;

    private DeviceProfile(int sdk, int memoryClassMb, boolean lowRam) {
        this.sdk = sdk;
        this.memoryClassMb = memoryClassMb;
        this.lowRam = lowRam;
    }

    static DeviceProfile detect(Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        int memoryClass = manager == null ? 192 : manager.getMemoryClass();
        boolean low = manager != null && manager.isLowRamDevice();
        return new DeviceProfile(Build.VERSION.SDK_INT, memoryClass, low);
    }

    int hotWebViewLimit(String mode) {
        if (lowRam || memoryClassMb < 192 || "power_save".equals(mode)) return 1;
        if ("performance".equals(mode)) return memoryClassMb >= 512 ? 3 : 2;
        return memoryClassMb >= 256 ? 2 : 1;
    }

    boolean allowPrewarmedWebView(String mode) {
        if (lowRam || memoryClassMb < 256 || "power_save".equals(mode)) return false;
        return "performance".equals(mode) || memoryClassMb >= 384;
    }

    boolean allowOffscreenPreRaster(String mode) {
        return "performance".equals(mode) && !lowRam && memoryClassMb >= 256;
    }

    String summary() {
        return "Android 8+ 优化路径 · API " + sdk + " · Java 堆上限 " + memoryClassMb + "MB" + (lowRam ? " · 低内存设备" : "");
    }
}
