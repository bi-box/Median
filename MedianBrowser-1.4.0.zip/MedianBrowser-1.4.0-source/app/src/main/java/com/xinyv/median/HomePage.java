package com.xinyv.median;

import android.net.Uri;

import java.util.List;

/** Fully local start page: zero startup network requests and no JavaScript bridge. */
final class HomePage {
    static String html(String selectedEngine, List<BrowserDataStore.Bookmark> bookmarks, boolean dark, String trustToken) {
        String engine = "baidu".equals(selectedEngine) || "bing".equals(selectedEngine) || "custom".equals(selectedEngine) ? selectedEngine : "google";
        String background = dark ? "#111315" : "#fff";
        String foreground = dark ? "#edf0f2" : "#202124";
        String secondary = dark ? "#aeb4ba" : "#5f6368";
        String surface = dark ? "#202327" : "#f1f3f4";
        String border = dark ? "#34383d" : "#dfe1e5";
        StringBuilder shortcuts = new StringBuilder();
        int count = Math.min(12, bookmarks == null ? 0 : bookmarks.size());
        for (int i = 0; i < count; i++) {
            BrowserDataStore.Bookmark item = bookmarks.get(i);
            String title = item.title == null || item.title.trim().length() == 0 ? host(item.url) : item.title.trim();
            if (title.length() > 18) title = title.substring(0, 18) + "…";
            String letter = title.length() == 0 ? "•" : title.substring(0, 1).toUpperCase(java.util.Locale.getDefault());
            shortcuts.append("<a class='shortcut' href='median://open?url=")
                    .append(Uri.encode(item.url)).append("'><span class='tile'>")
                    .append(escape(letter)).append("</span><span class='label'>")
                    .append(escape(title)).append("</span></a>");
        }
        if (count == 0) shortcuts.append("<button class='empty' onclick=\"location.href='median://bookmarks'\">添加常用书签</button>");

        return "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1'>" +
                "<meta name='median-home-token' content='" + escape(trustToken) + "'><meta name='color-scheme' content='" + (dark ? "dark" : "light") + "'><style>*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}html,body{margin:0;min-height:100%;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;background:" + background + ";color:" + foreground + "}" +
                "body{display:flex;justify-content:center}.wrap{width:100%;max-width:680px;padding:10vh 20px 44px;text-align:center;opacity:0;transform:translateY(10px);animation:enter .38s cubic-bezier(.2,0,0,1) forwards}.brand{font-size:47px;font-weight:720;letter-spacing:-2.5px;margin:0 0 25px}.brand i{font-style:normal;color:#1a73e8}" +
                ".search{height:54px;transform:translateZ(0);border:1px solid " + border + ";border-radius:28px;display:flex;align-items:center;padding:0 18px;background:" + background + ";box-shadow:0 2px 8px rgba(0,0,0,.12);transition:box-shadow .18s,transform .16s}.search:focus-within{transform:scale(1.009);box-shadow:0 4px 15px rgba(0,0,0,.18)}.mag{width:15px;height:15px;border:2px solid " + secondary + ";border-radius:50%;position:relative;flex:none;margin:0 15px 0 2px}.mag:after{content:'';position:absolute;width:7px;height:2px;background:" + secondary + ";right:-6px;bottom:-3px;transform:rotate(45deg);border-radius:2px}.search input{border:0;outline:0;font-size:17px;flex:1;min-width:0;background:transparent;color:" + foreground + "}" +
                ".engines{display:flex;justify-content:center;margin-top:18px;flex-wrap:wrap}.chip{border:0;background:transparent;border-radius:18px;padding:8px 14px;margin:3px;font-size:13px;color:" + secondary + "}.chip:active{transform:scale(.9)}.chip.active{background:" + surface + ";font-weight:650;color:" + foreground + "}" +
                ".shortcuts{display:grid;grid-template-columns:repeat(4,1fr);gap:16px 8px;margin:32px auto 0;max-width:440px}.shortcut{text-decoration:none;color:" + foreground + ";min-width:0;display:flex;flex-direction:column;align-items:center}.tile{display:grid;place-items:center;width:50px;height:50px;border-radius:16px;background:" + surface + ";font-size:19px;font-weight:650;box-shadow:0 1px 3px rgba(0,0,0,.08);transition:transform .14s}.shortcut:active .tile{transform:scale(.86)}.label{width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:7px;font-size:12px}.empty{grid-column:1/-1;border:1px dashed " + border + ";background:transparent;color:" + secondary + ";border-radius:16px;padding:16px}.median{position:fixed;top:16px;left:18px;font-size:13px;font-weight:650;color:" + secondary + "}" +
                "@keyframes enter{to{opacity:1;transform:none}}@media(prefers-reduced-motion:reduce){.wrap{animation:none;opacity:1;transform:none}.search,.tile{transition:none}}@media(max-height:600px){.wrap{padding-top:6vh}.brand{font-size:39px;margin-bottom:17px}.shortcuts{margin-top:20px}}</style></head>" +
                "<body><div class='median'>Median</div><main class='wrap'><div class='brand'>Med<i>i</i>an</div><form id='form'><div class='search'><span class='mag'></span><input id='q' autocomplete='off' enterkeyhint='search' placeholder='搜索或输入网址'></div></form>" +
                "<div class='engines'><button class='chip' data-e='google'>Google</button><button class='chip' data-e='baidu'>百度</button><button class='chip' data-e='bing'>Bing</button><button class='chip' data-e='custom'>自定义</button></div><div class='shortcuts'>" + shortcuts + "</div></main>" +
                "<script>let e='" + engine + "';function draw(){document.querySelectorAll('.chip').forEach(x=>x.classList.toggle('active',x.dataset.e===e))}document.querySelectorAll('.chip').forEach(x=>x.onclick=function(ev){ev.preventDefault();e=this.dataset.e;draw();location.href='median://engine?name='+e});document.getElementById('form').onsubmit=function(ev){ev.preventDefault();let q=document.getElementById('q').value.trim();if(q)location.href='median://search?engine='+e+'&q='+encodeURIComponent(q)};draw()</script></body></html>";
    }

    private static String host(String url) {
        try {
            String value = Uri.parse(url).getHost();
            if (value == null) return "书签";
            return value.startsWith("www.") ? value.substring(4) : value;
        } catch (Exception ignored) { return "书签"; }
    }

    private static String escape(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    private HomePage() {}
}
