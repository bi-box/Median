package com.xinyv.median;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Full-screen professional download manager with live telemetry and task controls. */
public final class DownloadCenterActivity extends Activity {
    private static final String PREFS = "median_browser_v2";
    private static final int BG = Color.rgb(247, 249, 252);
    private static final int CARD = Color.WHITE;
    private static final int TEXT = Color.rgb(31, 35, 41);
    private static final int MUTED = Color.rgb(102, 112, 125);
    private static final int PRIMARY = Color.rgb(26, 115, 232);
    private static final int GREEN = Color.rgb(24, 128, 56);
    private static final int RED = Color.rgb(196, 43, 28);
    private static final int AMBER = Color.rgb(180, 104, 0);
    private static final int LINE = Color.rgb(224, 229, 236);

    private static final int FILTER_ALL = 0;
    private static final int FILTER_ACTIVE = 1;
    private static final int FILTER_COMPLETED = 2;
    private static final int FILTER_PROBLEM = 3;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresher = new Runnable() {
        @Override public void run() {
            refresh();
            handler.postDelayed(this, 850L);
        }
    };

    private DownloadStore store;
    private SharedPreferences prefs;
    private LinearLayout taskList;
    private TextView summaryTitle;
    private TextView summaryDetail;
    private TextView memoryDetail;
    private TextView emptyView;
    private final Button[] filterButtons = new Button[4];
    private final Button[] modeButtons = new Button[3];
    private int filter = FILTER_ALL;
    private boolean resumed;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window window = getWindow();
        window.setStatusBarColor(Color.WHITE);
        window.setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= 23) window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        store = new DownloadStore(this);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        setContentView(buildUi());
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        handler.removeCallbacks(refresher);
        refresher.run();
    }

    @Override protected void onPause() {
        resumed = false;
        handler.removeCallbacks(refresher);
        super.onPause();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        root.addView(buildHeader(), new LinearLayout.LayoutParams(-1, dp(64)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(10), dp(16), dp(28));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));

        content.addView(buildSummaryCard(), marginParams(-1, -2, 0, 0, 0, 12));
        content.addView(buildModeCard(), marginParams(-1, -2, 0, 0, 0, 12));
        content.addView(buildFilterBar(), marginParams(-1, -2, 0, 0, 0, 10));

        emptyView = text("还没有下载任务", 15, MUTED, Gravity.CENTER);
        emptyView.setPadding(dp(16), dp(50), dp(16), dp(50));
        content.addView(emptyView, new LinearLayout.LayoutParams(-1, -2));

        taskList = new LinearLayout(this);
        taskList.setOrientation(LinearLayout.VERTICAL);
        content.addView(taskList, new LinearLayout.LayoutParams(-1, -2));

        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        return root;
    }

    private View buildHeader() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), 0, dp(8), 0);
        bar.setBackgroundColor(Color.WHITE);
        bar.setElevation(dp(2));

        Button back = compactButton("‹", false);
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
        back.setContentDescription("返回");
        back.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { finish(); } });
        bar.addView(back, new LinearLayout.LayoutParams(dp(52), dp(52)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("下载中心", 20, TEXT, Gravity.LEFT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView subtitle = text("断点续传 · 分段状态 · 实时性能", 12, MUTED, Gravity.LEFT);
        titles.addView(title);
        titles.addView(subtitle);
        bar.addView(titles, new LinearLayout.LayoutParams(0, -1, 1f));

        Button system = compactButton("系统", false);
        system.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
                catch (Exception e) { toast("系统下载管理器不可用"); }
            }
        });
        bar.addView(system, new LinearLayout.LayoutParams(dp(58), dp(40)));
        return bar;
    }

    private View buildSummaryCard() {
        LinearLayout card = card();
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        summaryTitle = text("0 个活动任务", 22, TEXT, Gravity.LEFT);
        summaryTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        summaryDetail = text("总速度 0 B/s", 13, MUTED, Gravity.LEFT);
        summaryDetail.setPadding(0, dp(5), 0, 0);
        card.addView(summaryTitle);
        card.addView(summaryDetail);
        return card;
    }

    private View buildModeCard() {
        LinearLayout card = card();
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        TextView title = text("下载性能与内存", 16, TEXT, Gravity.LEFT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.addView(title);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(12), 0, dp(8));
        String[] labels = new String[] { "极限", "标准", "低功耗" };
        final String[] modes = new String[] { DownloadMemoryPolicy.MODE_PERFORMANCE,
                DownloadMemoryPolicy.MODE_STANDARD, DownloadMemoryPolicy.MODE_POWER_SAVE };
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            Button button = compactButton(labels[i], true);
            button.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    prefs.edit().putString("performance_mode", modes[index]).apply();
                    refreshModeCard();
                    toast("新任务将使用" + modeLabel(modes[index]) + "；活动任务保持原档位");
                }
            });
            modeButtons[i] = button;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
            if (i > 0) lp.leftMargin = dp(8);
            row.addView(button, lp);
        }
        card.addView(row);
        memoryDetail = text("", 12, MUTED, Gravity.LEFT);
        memoryDetail.setLineSpacing(0, 1.12f);
        card.addView(memoryDetail);
        return card;
    }

    private View buildFilterBar() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        String[] labels = new String[] { "全部", "进行中", "已完成", "异常" };
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            Button button = compactButton(labels[i], true);
            button.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    filter = index;
                    refreshFilterButtons();
                    refreshTasks();
                }
            });
            filterButtons[i] = button;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(86), dp(40));
            if (i > 0) lp.leftMargin = dp(8);
            row.addView(button, lp);
        }
        scroll.addView(row, new HorizontalScrollView.LayoutParams(-2, -2));
        return scroll;
    }

    private void refresh() {
        if (!resumed) return;
        refreshModeCard();
        refreshFilterButtons();
        refreshTasks();
    }

    private void refreshModeCard() {
        String mode = currentMode();
        String[] modes = new String[] { DownloadMemoryPolicy.MODE_PERFORMANCE,
                DownloadMemoryPolicy.MODE_STANDARD, DownloadMemoryPolicy.MODE_POWER_SAVE };
        for (int i = 0; i < modeButtons.length; i++) styleToggle(modeButtons[i], modes[i].equals(mode));
        memoryDetail.setText(DownloadMemoryPolicy.diagnostics(this, mode) +
                "\n内存压力达到危险级时，任务会保存分段游标并自动暂停，而不是让 WebView 被系统回收。");
    }

    private void refreshFilterButtons() {
        for (int i = 0; i < filterButtons.length; i++) styleToggle(filterButtons[i], i == filter);
    }

    private void refreshTasks() {
        List<DownloadStore.Item> all = store.getAll();
        ArrayList<DownloadStore.Item> visible = new ArrayList<DownloadStore.Item>();
        int active = 0;
        int paused = 0;
        int completed = 0;
        long speed = 0L;
        long remaining = 0L;
        for (DownloadStore.Item item : all) {
            String status = effectiveStatus(item);
            if (isActiveStatus(status)) {
                active++;
                speed += Math.max(0L, item.bytesPerSecond);
                if (item.totalBytes > item.downloadedBytes) remaining += item.totalBytes - item.downloadedBytes;
            }
            if (DownloadStore.STATUS_PAUSED.equals(status)) paused++;
            if (DownloadStore.STATUS_COMPLETED.equals(status)) completed++;
            if (matchesFilter(status)) visible.add(item);
        }
        summaryTitle.setText(active + " 个活动任务" + (paused > 0 ? " · " + paused + " 个暂停" : ""));
        String eta = speed > 0L && remaining > 0L ? " · 总剩余约 " + humanDuration(remaining / speed) : "";
        summaryDetail.setText("总速度 " + humanSpeed(speed) + eta + " · 已完成 " + completed + " · 可用空间 " + availableStorage());

        taskList.removeAllViews();
        int limit = Math.min(visible.size(), 120);
        emptyView.setVisibility(limit == 0 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < limit; i++) taskList.addView(buildTaskCard(visible.get(i)), marginParams(-1, -2, 0, 0, 0, 10));
        if (visible.size() > limit) {
            TextView more = text("为保持页面流畅，仅显示前 " + limit + " 条；其余记录仍保存在本机。", 12, MUTED, Gravity.CENTER);
            more.setPadding(dp(8), dp(12), dp(8), dp(12));
            taskList.addView(more);
        }
    }

    private View buildTaskCard(final DownloadStore.Item item) {
        LinearLayout card = card();
        card.setPadding(dp(15), dp(14), dp(15), dp(13));
        card.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showDetails(item); } });

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.TOP);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView title = text(item.filename.length() == 0 ? "未命名下载" : item.filename, 15, TEXT, Gravity.LEFT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView badge = badge(statusLabel(item), statusColor(item));
        LinearLayout.LayoutParams badgeParams = new LinearLayout.LayoutParams(-2, dp(28));
        badgeParams.leftMargin = dp(10);
        titleRow.addView(badge, badgeParams);
        card.addView(titleRow);

        long total = Math.max(0L, item.totalBytes);
        long current = Math.max(0L, item.downloadedBytes);
        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        progress.setProgress(total > 0L ? (int) Math.min(1000L, current * 1000L / total) : 0);
        progress.setIndeterminate(total <= 0L && item.isActive());
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(statusColor(item)));
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, dp(6));
        progressParams.topMargin = dp(12);
        card.addView(progress, progressParams);

        StringBuilder line = new StringBuilder();
        line.append(total > 0L ? humanBytes(current) + " / " + humanBytes(total) : humanBytes(current));
        if (item.bytesPerSecond > 0L) line.append(" · ").append(humanSpeed(item.bytesPerSecond));
        if (item.etaSeconds > 0L && item.isActive()) line.append(" · 剩余 ").append(humanDuration(item.etaSeconds));
        TextView telemetry = text(line.toString(), 13, TEXT, Gravity.LEFT);
        telemetry.setPadding(0, dp(9), 0, 0);
        card.addView(telemetry);

        String technical;
        if (item.isAdaptive()) {
            technical = modeLabel(item.mode) + " · " + Math.max(1, item.segmentCount) + " 段 · " +
                    (item.bufferBytes > 0 ? humanBytes(item.bufferBytes) + " 缓冲" : "自适应缓冲") +
                    (item.memoryBudgetBytes > 0 ? " · 预算 " + humanBytes(item.memoryBudgetBytes) : "") +
                    (item.rangeSupported ? " · 可续传" : " · 服务器不支持断点");
        } else technical = "Android 系统下载任务";
        TextView details = text(technical, 11, MUTED, Gravity.LEFT);
        details.setPadding(0, dp(4), 0, 0);
        details.setMaxLines(2);
        card.addView(details);

        if (item.reason.length() > 0 && !DownloadStore.STATUS_COMPLETED.equals(item.status)) {
            TextView reason = text(item.reason, 11, statusColor(item), Gravity.LEFT);
            reason.setPadding(0, dp(4), 0, 0);
            reason.setMaxLines(2);
            card.addView(reason);
        }

        HorizontalScrollView actionsScroll = new HorizontalScrollView(this);
        actionsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(11), 0, 0);
        addTaskActions(actions, item);
        actionsScroll.addView(actions, new HorizontalScrollView.LayoutParams(-2, -2));
        card.addView(actionsScroll);
        return card;
    }

    private void addTaskActions(LinearLayout row, final DownloadStore.Item item) {
        String status = effectiveStatus(item);
        if (item.isAdaptive() && isActiveStatus(status)) {
            addAction(row, "暂停", new View.OnClickListener() { @Override public void onClick(View v) { sendService(item.id, AdaptiveDownloadService.ACTION_PAUSE, false); } });
            addAction(row, "取消", new View.OnClickListener() { @Override public void onClick(View v) { confirmCancel(item); } });
        } else if (item.isAdaptive() && (DownloadStore.STATUS_PAUSED.equals(status) || DownloadStore.STATUS_FAILED.equals(status))) {
            addAction(row, "继续", new View.OnClickListener() { @Override public void onClick(View v) { resume(item, false); } });
            addAction(row, "当前档继续", new View.OnClickListener() { @Override public void onClick(View v) { resume(item, true); } });
            addAction(row, "取消", new View.OnClickListener() { @Override public void onClick(View v) { confirmCancel(item); } });
        } else if (DownloadStore.STATUS_COMPLETED.equals(status)) {
            addAction(row, "打开", new View.OnClickListener() { @Override public void onClick(View v) { openFile(item, false); } });
            addAction(row, "分享", new View.OnClickListener() { @Override public void onClick(View v) { openFile(item, true); } });
            addAction(row, "移除记录", new View.OnClickListener() { @Override public void onClick(View v) { store.remove(item.id); refreshTasks(); } });
        } else {
            addAction(row, "重试", new View.OnClickListener() { @Override public void onClick(View v) { resume(item, true); } });
            addAction(row, "移除记录", new View.OnClickListener() { @Override public void onClick(View v) { store.remove(item.id); refreshTasks(); } });
        }
        addAction(row, "详情", new View.OnClickListener() { @Override public void onClick(View v) { showDetails(item); } });
    }

    private void resume(DownloadStore.Item item, boolean useCurrentMode) {
        if (!item.isAdaptive()) {
            try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
            catch (Exception e) { toast("请在系统下载管理器中处理此任务"); }
            return;
        }
        if (useCurrentMode) store.updateMode(item.id, currentMode());
        sendService(item.id, AdaptiveDownloadService.ACTION_RESUME, true);
        toast("正在恢复下载");
    }

    private void confirmCancel(final DownloadStore.Item item) {
        new AlertDialog.Builder(this).setTitle("取消下载？")
                .setMessage("将删除未完成的临时文件和分段状态。")
                .setPositiveButton("取消任务", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        sendService(item.id, AdaptiveDownloadService.ACTION_CANCEL, false);
                        toast("已请求取消任务");
                    }
                }).setNegativeButton("返回", null).show();
    }

    private void sendService(long id, String action, boolean foreground) {
        Intent intent = new Intent(this, AdaptiveDownloadService.class);
        intent.setAction(action);
        intent.putExtra(AdaptiveDownloadService.EXTRA_ID, id);
        try {
            if (foreground && Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
        } catch (RuntimeException e) { toast("任务操作失败：" + e.getClass().getSimpleName()); }
    }

    private void showDetails(final DownloadStore.Item original) {
        DownloadStore.Item refreshed = store.get(original.id);
        final DownloadStore.Item item = refreshed == null ? original : refreshed;
        StringBuilder message = new StringBuilder();
        message.append("状态：").append(statusLabel(item));
        if (item.reason.length() > 0) message.append("\n说明：").append(item.reason);
        message.append("\n\n文件：").append(item.filename);
        message.append("\n大小：").append(item.totalBytes > 0L ? humanBytes(item.totalBytes) : "未知");
        message.append("\n已下载：").append(humanBytes(item.downloadedBytes));
        message.append("\n当前速度：").append(humanSpeed(item.bytesPerSecond));
        message.append("\n峰值速度：").append(humanSpeed(item.peakBytesPerSecond));
        message.append("\n平均速度：").append(humanSpeed(item.averageBytesPerSecond));
        if (item.isAdaptive()) {
            message.append("\n性能档：").append(modeLabel(item.mode));
            message.append("\n分段：").append(item.segmentCount);
            message.append("\n每段缓冲：").append(humanBytes(item.bufferBytes));
            message.append("\n内存预算：").append(humanBytes(item.memoryBudgetBytes));
            message.append("\n断点续传：").append(item.rangeSupported ? "支持" : "服务器不支持");
            message.append("\n自动重试：").append(item.retryCount).append(" 次");
        }
        message.append("\n创建时间：").append(formatTime(item.createdAt));
        if (item.completedAt > 0L) message.append("\n完成时间：").append(formatTime(item.completedAt));
        message.append("\n\n地址：").append(item.url);
        new AlertDialog.Builder(this).setTitle("下载详情").setMessage(message.toString())
                .setPositiveButton("复制地址", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (clipboard != null) clipboard.setPrimaryClip(android.content.ClipData.newPlainText("下载地址", item.url));
                        toast("下载地址已复制");
                    }
                }).setNegativeButton("关闭", null).show();
    }

    private void openFile(DownloadStore.Item item, boolean share) {
        try {
            Uri uri = downloadedUri(item);
            if (uri == null) { toast("文件不存在或尚未完成"); return; }
            Intent intent;
            String mime = item.mime.length() == 0 ? "application/octet-stream" : item.mime;
            if (share) {
                intent = new Intent(Intent.ACTION_SEND);
                intent.setType(mime);
                intent.putExtra(Intent.EXTRA_STREAM, uri);
            } else {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(uri, mime);
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(share ? Intent.createChooser(intent, "分享下载文件") : intent);
        } catch (Exception e) { toast("没有应用可以处理此文件"); }
    }

    private Uri downloadedUri(DownloadStore.Item item) {
        if (item.isAdaptive()) {
            if (!DownloadStore.STATUS_COMPLETED.equals(item.status) || item.localUri.length() == 0) return null;
            try { return Uri.parse(item.localUri); } catch (RuntimeException e) { return null; }
        }
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        return manager == null ? null : manager.getUriForDownloadedFile(item.id);
    }

    private boolean matchesFilter(String status) {
        if (filter == FILTER_ALL) return true;
        if (filter == FILTER_ACTIVE) return isActiveStatus(status) || DownloadStore.STATUS_PAUSED.equals(status);
        if (filter == FILTER_COMPLETED) return DownloadStore.STATUS_COMPLETED.equals(status);
        return DownloadStore.STATUS_FAILED.equals(status) || DownloadStore.STATUS_CANCELLED.equals(status);
    }

    private boolean isActiveStatus(String status) {
        return DownloadStore.STATUS_PENDING.equals(status) || DownloadStore.STATUS_WAITING.equals(status) ||
                DownloadStore.STATUS_DOWNLOADING.equals(status);
    }

    private String effectiveStatus(DownloadStore.Item item) {
        if (item.isAdaptive()) return item.status;
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        if (manager == null) return item.status;
        Cursor cursor = null;
        try {
            cursor = manager.query(new DownloadManager.Query().setFilterById(item.id));
            if (cursor == null || !cursor.moveToFirst()) return item.status;
            int status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            if (status == DownloadManager.STATUS_SUCCESSFUL) return DownloadStore.STATUS_COMPLETED;
            if (status == DownloadManager.STATUS_FAILED) return DownloadStore.STATUS_FAILED;
            if (status == DownloadManager.STATUS_PAUSED) return DownloadStore.STATUS_PAUSED;
            if (status == DownloadManager.STATUS_RUNNING) return DownloadStore.STATUS_DOWNLOADING;
            return DownloadStore.STATUS_PENDING;
        } catch (Exception e) { return item.status;
        } finally { if (cursor != null) cursor.close(); }
    }

    private String statusLabel(DownloadStore.Item item) {
        String status = effectiveStatus(item);
        if (DownloadStore.STATUS_COMPLETED.equals(status)) return "已完成";
        if (DownloadStore.STATUS_FAILED.equals(status)) return "失败";
        if (DownloadStore.STATUS_CANCELLED.equals(status)) return "已取消";
        if (DownloadStore.STATUS_PAUSED.equals(status)) return "已暂停";
        if (DownloadStore.STATUS_WAITING.equals(status)) return "等待条件";
        if (DownloadStore.STATUS_PENDING.equals(status)) return "准备中";
        return "下载中";
    }

    private int statusColor(DownloadStore.Item item) {
        String status = effectiveStatus(item);
        if (DownloadStore.STATUS_COMPLETED.equals(status)) return GREEN;
        if (DownloadStore.STATUS_FAILED.equals(status) || DownloadStore.STATUS_CANCELLED.equals(status)) return RED;
        if (DownloadStore.STATUS_PAUSED.equals(status) || DownloadStore.STATUS_WAITING.equals(status)) return AMBER;
        return PRIMARY;
    }

    private String currentMode() {
        String mode = prefs.getString("performance_mode", DownloadMemoryPolicy.MODE_STANDARD);
        if (!DownloadMemoryPolicy.MODE_PERFORMANCE.equals(mode) && !DownloadMemoryPolicy.MODE_POWER_SAVE.equals(mode))
            return DownloadMemoryPolicy.MODE_STANDARD;
        return mode;
    }

    private String modeLabel(String mode) {
        if (DownloadMemoryPolicy.MODE_PERFORMANCE.equals(mode)) return "极限性能";
        if (DownloadMemoryPolicy.MODE_POWER_SAVE.equals(mode)) return "低功耗";
        return "标准";
    }

    private String availableStorage() {
        try {
            StatFs stat = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            return humanBytes(stat.getAvailableBytes());
        } catch (RuntimeException e) { return "未知"; }
    }

    private LinearLayout card() {
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setBackground(rounded(CARD, dp(16), LINE, 1));
        view.setElevation(dp(1));
        return view;
    }

    private TextView badge(String label, int color) {
        TextView view = text(label, 11, color, Gravity.CENTER);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setPadding(dp(10), 0, dp(10), 0);
        view.setBackground(rounded(withAlpha(color, 22), dp(14), withAlpha(color, 55), 1));
        return view;
    }

    private void addAction(LinearLayout row, String label, View.OnClickListener listener) {
        Button button = compactButton(label, false);
        button.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(38));
        if (row.getChildCount() > 0) lp.leftMargin = dp(8);
        row.addView(button, lp);
    }

    private Button compactButton(String label, boolean full) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        button.setTextColor(TEXT);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setPadding(dp(full ? 10 : 13), 0, dp(full ? 10 : 13), 0);
        button.setBackground(rounded(Color.WHITE, dp(12), LINE, 1));
        return button;
    }

    private void styleToggle(Button button, boolean selected) {
        button.setTextColor(selected ? Color.WHITE : TEXT);
        button.setTypeface(Typeface.DEFAULT, selected ? Typeface.BOLD : Typeface.NORMAL);
        button.setBackground(rounded(selected ? PRIMARY : Color.WHITE, dp(12), selected ? PRIMARY : LINE, 1));
    }

    private TextView text(String value, int sp, int color, int gravity) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        view.setTextColor(color);
        view.setGravity(gravity);
        return view;
    }

    private GradientDrawable rounded(int color, int radius, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams marginParams(int width, int height, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private int dp(float value) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()));
    }

    private static int withAlpha(int color, int alpha) { return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color)); }

    private static String humanBytes(long bytes) {
        if (bytes <= 0L) return "0 B";
        if (bytes < 1024L) return bytes + " B";
        if (bytes < 1024L * 1024L) return String.format(Locale.US, "%.1f KB", bytes / 1024d);
        if (bytes < 1024L * 1024L * 1024L) return String.format(Locale.US, "%.1f MB", bytes / (1024d * 1024d));
        return String.format(Locale.US, "%.2f GB", bytes / (1024d * 1024d * 1024d));
    }

    private static String humanSpeed(long bytes) { return humanBytes(bytes) + "/s"; }

    private static String humanDuration(long seconds) {
        if (seconds < 60L) return Math.max(1L, seconds) + " 秒";
        if (seconds < 3600L) return (seconds / 60L) + " 分 " + (seconds % 60L) + " 秒";
        return (seconds / 3600L) + " 小时 " + ((seconds % 3600L) / 60L) + " 分";
    }

    private static String formatTime(long millis) {
        if (millis <= 0L) return "未知";
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date(millis));
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
}
