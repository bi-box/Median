package com.xinyv.median;

import android.app.ActivityManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.PowerManager;

/**
 * Converts device memory, CPU, thermal and network signals into download settings.
 * Extreme mode is intentionally aggressive, while retaining hard memory/thermal safety floors.
 */
final class DownloadMemoryPolicy {
    static final String MODE_PERFORMANCE = "performance";
    static final String MODE_STANDARD = "standard";
    static final String MODE_POWER_SAVE = "power_save";

    static final class Snapshot {
        final int memoryClassMb;
        final boolean lowRam;
        final long availableSystemMb;
        final long systemThresholdMb;
        final long heapUsedMb;
        final long heapFreeMb;
        final int cpuCores;
        final int downstreamKbps;
        final int thermalStatus;

        Snapshot(int memoryClassMb, boolean lowRam, long availableSystemMb, long systemThresholdMb,
                 long heapUsedMb, long heapFreeMb, int cpuCores, int downstreamKbps, int thermalStatus) {
            this.memoryClassMb = memoryClassMb;
            this.lowRam = lowRam;
            this.availableSystemMb = availableSystemMb;
            this.systemThresholdMb = systemThresholdMb;
            this.heapUsedMb = heapUsedMb;
            this.heapFreeMb = heapFreeMb;
            this.cpuCores = cpuCores;
            this.downstreamKbps = downstreamKbps;
            this.thermalStatus = thermalStatus;
        }
    }

    static final class Plan {
        final int maxSegments;
        final int bufferBytes;
        final long memoryBudgetBytes;
        final long maxBytesPerSecond;
        final int maxParallelTasks;
        final String summary;

        Plan(int maxSegments, int bufferBytes, long memoryBudgetBytes, long maxBytesPerSecond,
             int maxParallelTasks, String summary) {
            this.maxSegments = maxSegments;
            this.bufferBytes = bufferBytes;
            this.memoryBudgetBytes = memoryBudgetBytes;
            this.maxBytesPerSecond = maxBytesPerSecond;
            this.maxParallelTasks = maxParallelTasks;
            this.summary = summary;
        }
    }

    private DownloadMemoryPolicy() {}

    static Snapshot snapshot(Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        int memoryClass = manager == null ? 128 : Math.max(64, manager.getMemoryClass());
        boolean lowRam = manager != null && manager.isLowRamDevice();
        long availableMb = 0L;
        long thresholdMb = 0L;
        if (manager != null) {
            ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
            manager.getMemoryInfo(info);
            availableMb = info.availMem / (1024L * 1024L);
            thresholdMb = info.threshold / (1024L * 1024L);
        }
        Runtime runtime = Runtime.getRuntime();
        long used = runtime.totalMemory() - runtime.freeMemory();
        long free = Math.max(0L, runtime.maxMemory() - used);
        int downstream = 0;
        try {
            ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities caps = connectivity == null ? null : connectivity.getNetworkCapabilities(connectivity.getActiveNetwork());
            if (caps != null) downstream = Math.max(0, caps.getLinkDownstreamBandwidthKbps());
        } catch (RuntimeException ignored) {}
        int thermal = PowerManager.THERMAL_STATUS_NONE;
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                PowerManager power = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                if (power != null) thermal = power.getCurrentThermalStatus();
            } catch (RuntimeException ignored) {}
        }
        return new Snapshot(memoryClass, lowRam, availableMb, thresholdMb,
                used / (1024L * 1024L), free / (1024L * 1024L),
                Math.max(1, Runtime.getRuntime().availableProcessors()), downstream, thermal);
    }

    static Plan plan(Context context, String mode, long totalBytes) {
        return plan(context, mode, totalBytes, 1);
    }

    static Plan plan(Context context, String mode, long totalBytes, int activeTasks) {
        Snapshot s = snapshot(context);
        int taskCount = Math.max(1, activeTasks);
        long mib = 1024L * 1024L;
        long freeHeapBytes = Math.max(8L * mib, s.heapFreeMb * mib);
        boolean memoryPressure = s.availableSystemMb > 0L &&
                s.availableSystemMb < Math.max(s.systemThresholdMb * 2L, 384L);
        boolean hot = Build.VERSION.SDK_INT >= 29 && s.thermalStatus >= PowerManager.THERMAL_STATUS_SEVERE;

        if (MODE_POWER_SAVE.equals(mode)) {
            int buffer = memoryPressure || s.lowRam ? 32 * 1024 : 64 * 1024;
            long budget = Math.min(2L * mib, freeHeapBytes / 24L);
            return new Plan(1, buffer, Math.max(buffer * 2L, budget),
                    2L * mib, 1,
                    "单连接 · " + humanBuffer(buffer) + " 缓冲 · 约 2 MB/s 上限");
        }

        if (MODE_PERFORMANCE.equals(mode)) {
            int buffer;
            if (s.lowRam || memoryPressure) buffer = 256 * 1024;
            else if (s.memoryClassMb >= 512 && s.heapFreeMb >= 256) buffer = 1024 * 1024;
            else if (s.memoryClassMb >= 256 && s.heapFreeMb >= 128) buffer = 512 * 1024;
            else buffer = 384 * 1024;

            // A single extreme task may consume up to 60% of currently free Java heap,
            // but simultaneous tasks share the pool instead of each claiming the full budget.
            long globalBudget = Math.min(192L * mib, Math.max(24L * mib, freeHeapBytes * 3L / 5L));
            long budget = Math.max(12L * mib, globalBudget / taskCount);
            if (memoryPressure || s.lowRam) budget = Math.min(budget, 32L * mib);
            if (hot) budget = Math.min(budget, 48L * mib);

            int byCpu = Math.max(16, s.cpuCores * 8);
            int byMemory = (int) Math.max(4L, budget / Math.max(1L, buffer + 96L * 1024L));
            int byNetwork;
            if (s.downstreamKbps <= 0) byNetwork = 48;
            else if (s.downstreamKbps < 20_000) byNetwork = 8;
            else if (s.downstreamKbps < 80_000) byNetwork = 16;
            else if (s.downstreamKbps < 250_000) byNetwork = 32;
            else if (s.downstreamKbps < 800_000) byNetwork = 48;
            else byNetwork = 64;
            int byFile = totalBytes <= 0L ? 48 : (int) Math.max(1L, Math.min(64L,
                    (totalBytes + 2L * mib - 1L) / (2L * mib)));
            int segments = clamp(Math.min(Math.min(byCpu, byMemory), Math.min(byNetwork, byFile)), 4, 64);
            if (s.lowRam || memoryPressure) segments = Math.min(segments, 12);
            if (hot) segments = Math.min(segments, Math.max(8, s.cpuCores * 2));
            return new Plan(segments, buffer, budget, 0L, hot ? 2 : 6,
                    segments + " 分段上限 · " + humanBuffer(buffer) + " 每段 · 内存预算 " +
                            humanBytes(budget) + " · 不限速" + (hot ? " · 高温保护" : ""));
        }

        int buffer;
        if (s.lowRam || memoryPressure) buffer = 96 * 1024;
        else if (s.memoryClassMb >= 384 && s.heapFreeMb >= 160) buffer = 256 * 1024;
        else buffer = 128 * 1024;
        // Standard mode targets a 100 Mbps access link rather than workstation-class throughput.
        // Keep enough concurrency to hide mobile-network latency without wasting RAM or sockets.
        long globalBudget = Math.min(24L * mib, Math.max(6L * mib, freeHeapBytes / 5L));
        long budget = Math.max(4L * mib, globalBudget / Math.min(taskCount, 3));
        if (memoryPressure || s.lowRam) budget = Math.min(budget, 8L * mib);
        if (hot) budget = Math.min(budget, 12L * mib);
        int byMemory = (int) Math.max(2L, budget / Math.max(1L, buffer + 64L * 1024L));
        int byCpu = Math.max(3, s.cpuCores);
        int byNetwork;
        if (s.downstreamKbps <= 0) byNetwork = 6;
        else if (s.downstreamKbps < 20_000) byNetwork = 3;
        else if (s.downstreamKbps < 60_000) byNetwork = 4;
        else byNetwork = 8;
        int byFile = totalBytes <= 0L ? 6 : (int) Math.max(1L, Math.min(8L,
                (totalBytes + 8L * mib - 1L) / (8L * mib)));
        int segments = clamp(Math.min(Math.min(byCpu, byMemory), Math.min(byNetwork, byFile)), 2, 8);
        if (s.lowRam || memoryPressure) segments = Math.min(segments, 4);
        if (hot) segments = Math.min(segments, 4);
        long standardLimit = 100_000_000L / 8L; // 100 Mbps = 12.5 MB/s (decimal)
        return new Plan(segments, buffer, budget, standardLimit, 3,
                segments + " 分段上限 · " + humanBuffer(buffer) + " 每段 · 内存预算 " +
                        humanBytes(budget) + " · 约 100 Mbps 上限" + (hot ? " · 高温保护" : ""));
    }

    static String diagnostics(Context context, String mode) {
        Snapshot s = snapshot(context);
        Plan p = plan(context, mode, -1L);
        return "内存档：" + (s.lowRam ? "低内存设备" : s.memoryClassMb + " MB 应用堆") +
                " · 堆已用 " + s.heapUsedMb + " MB · 可扩展约 " + s.heapFreeMb + " MB" +
                "\n系统可用：" + s.availableSystemMb + " MB · 回收阈值 " + s.systemThresholdMb + " MB" +
                "\n下载计划：" + p.summary +
                "\nCPU：" + s.cpuCores + " 核" +
                (s.downstreamKbps > 0 ? " · 链路估计 " + s.downstreamKbps + " kbps" : "") +
                (Build.VERSION.SDK_INT >= 29 ? " · 温控状态 " + thermalLabel(s.thermalStatus) : "");
    }

    private static String thermalLabel(int status) {
        if (status >= PowerManager.THERMAL_STATUS_EMERGENCY) return "紧急";
        if (status >= PowerManager.THERMAL_STATUS_CRITICAL) return "临界";
        if (status >= PowerManager.THERMAL_STATUS_SEVERE) return "严重";
        if (status >= PowerManager.THERMAL_STATUS_MODERATE) return "中等";
        if (status >= PowerManager.THERMAL_STATUS_LIGHT) return "轻微";
        return "正常";
    }

    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }

    static String humanBytes(long bytes) {
        if (bytes < 1024L * 1024L) return Math.max(1L, bytes / 1024L) + " KB";
        return Math.max(1L, bytes / (1024L * 1024L)) + " MB";
    }

    private static String humanBuffer(int bytes) {
        return bytes >= 1024 * 1024 ? (bytes / (1024 * 1024)) + " MB" : (bytes / 1024) + " KB";
    }
}
