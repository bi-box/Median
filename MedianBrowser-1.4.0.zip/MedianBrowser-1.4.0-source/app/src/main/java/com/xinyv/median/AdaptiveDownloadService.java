package com.xinyv.median;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentCallbacks2;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.webkit.CookieManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Resumable, range-aware foreground downloader. Segment cursors are persisted so a
 * manual pause, process restart or transient failure does not discard completed data.
 */
public final class AdaptiveDownloadService extends Service {
    static final String ACTION_DOWNLOAD = "com.xinyv.median.action.ADAPTIVE_DOWNLOAD";
    static final String ACTION_PAUSE = "com.xinyv.median.action.PAUSE_ADAPTIVE_DOWNLOAD";
    static final String ACTION_RESUME = "com.xinyv.median.action.RESUME_ADAPTIVE_DOWNLOAD";
    static final String ACTION_CANCEL = "com.xinyv.median.action.CANCEL_ADAPTIVE_DOWNLOAD";
    static final String EXTRA_ID = "id";
    static final String EXTRA_URL = "url";
    static final String EXTRA_NAME = "name";
    static final String EXTRA_MIME = "mime";
    static final String EXTRA_USER_AGENT = "user_agent";
    static final String EXTRA_COOKIE = "cookie";
    static final String EXTRA_HEADERS = "headers";
    static final String EXTRA_MODE = "mode";
    static final String EXTRA_WIFI_ONLY = "wifi_only";
    static final String EXTRA_ALLOW_ROAMING = "allow_roaming";
    static final String EXTRA_CHARGING_ONLY = "charging_only";
    static final String EXTRA_PUBLIC_ONLY = "public_only";

    private static final String CHANNEL_ID = "median_adaptive_downloads_v2";
    private static final int FOREGROUND_ID = 7101;
    private static final long MIB = 1024L * 1024L;
    private static final int TASK_THREADS = Math.max(4, Math.min(8, Runtime.getRuntime().availableProcessors()));
    private static final ExecutorService TASK_EXECUTOR = Executors.newFixedThreadPool(TASK_THREADS);
    private static final ConcurrentHashMap<Long, Control> CONTROLS = new ConcurrentHashMap<Long, Control>();

    private final AtomicInteger activeTasks = new AtomicInteger();
    private NotificationManager notificationManager;
    private DownloadStore store;

    @Override public void onCreate() {
        super.onCreate();
        store = new DownloadStore(this);
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && notificationManager != null) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "专业下载", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Median 断点续传、分段下载与任务控制");
            channel.setShowBadge(false);
            notificationManager.createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, final int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        final long id = intent.getLongExtra(EXTRA_ID, 0L);

        if (ACTION_PAUSE.equals(action)) {
            Control control = CONTROLS.get(Long.valueOf(id));
            if (control != null) control.pause("已手动暂停");
            else markPaused(id, "已手动暂停");
            return START_NOT_STICKY;
        }
        if (ACTION_CANCEL.equals(action)) {
            Control control = CONTROLS.get(Long.valueOf(id));
            if (control != null) control.cancel();
            else {
                deletePartialFiles(id);
                DownloadStore.Item item = store.get(id);
                long total = item == null ? 0L : item.totalBytes;
                store.updateAdaptive(id, DownloadStore.STATUS_CANCELLED, "已取消", 0L, total, 0L, null);
                if (item != null) notifyTask(Task.fromStore(this, item), "已取消", 0, 0L, total, false, false);
            }
            return START_NOT_STICKY;
        }
        if (!ACTION_DOWNLOAD.equals(action) && !ACTION_RESUME.equals(action)) return START_NOT_STICKY;

        final Task task = ACTION_RESUME.equals(action) ? taskFromStore(id) : Task.fromIntent(intent);
        if (task == null || task.id >= 0L || task.url.length() == 0) {
            stopSelfResult(startId);
            return START_NOT_STICKY;
        }
        if (CONTROLS.containsKey(Long.valueOf(task.id))) return START_NOT_STICKY;

        startForegroundCompat(buildNotification(task, "正在准备下载", 0, 0L, 0L, true, false));
        activeTasks.incrementAndGet();
        TASK_EXECUTOR.execute(new Runnable() {
            @Override public void run() {
                runTask(task);
                if (activeTasks.decrementAndGet() <= 0) {
                    if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH);
                    else stopForeground(false);
                    stopSelfResult(startId);
                }
            }
        });
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
                level == ComponentCallbacks2.TRIM_MEMORY_COMPLETE) {
            for (Control control : CONTROLS.values()) control.pause("系统内存紧张，已安全暂停");
        }
    }

    @Override public void onLowMemory() {
        super.onLowMemory();
        for (Control control : CONTROLS.values()) control.pause("系统内存不足，已安全暂停");
    }

    /** Android 15+ limits dataSync foreground services to a shared six-hour budget. */
    @Override public void onTimeout(int startId, int fgsType) {
        for (Control control : CONTROLS.values()) {
            control.pause("系统已达到后台下载时限，请返回应用后继续");
        }
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        stopSelf(startId);
    }

    private void startForegroundCompat(Notification notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(FOREGROUND_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else startForeground(FOREGROUND_ID, notification);
    }

    private Task taskFromStore(long id) {
        DownloadStore.Item item = store.get(id);
        if (item == null || !item.isAdaptive()) return null;
        return Task.fromStore(this, item);
    }

    private void markPaused(long id, String reason) {
        DownloadStore.Item item = store.get(id);
        if (item == null || !item.isAdaptive()) return;
        store.updateAdaptiveTelemetry(id, DownloadStore.STATUS_PAUSED, reason,
                item.downloadedBytes, item.totalBytes, 0L, null, item.segmentCount,
                item.bufferBytes, item.memoryBudgetBytes, item.rangeSupported, item.etaSeconds, item.retryCount);
        notifyTask(Task.fromStore(this, item), reason, percent(item.downloadedBytes, item.totalBytes),
                item.downloadedBytes, item.totalBytes, false, true);
    }

    private void runTask(Task task) {
        Control control = new Control();
        Control previous = CONTROLS.putIfAbsent(Long.valueOf(task.id), control);
        if (previous != null) return;
        File temp = partialFile(task.id);
        File stateFile = stateFile(task.id);
        Locks locks = null;
        boolean completed = false;
        boolean cancelled = false;
        try {
            waitForConstraints(task, control);
            control.check();

            Probe probe = probe(task, control);
            DownloadMemoryPolicy.Plan memoryPlan = DownloadMemoryPolicy.plan(this, task.mode, probe.totalBytes, activeTasks.get());
            Profile profile = Profile.from(task.mode, memoryPlan);
            setCurrentThreadPriority(profile.threadPriority);
            locks = acquireLocks(profile);

            DownloadState state = DownloadState.load(stateFile);
            if (state == null || !state.matches(task, probe) || !temp.exists()) {
                deleteQuietly(temp);
                deleteQuietly(stateFile);
                int segmentCount = chooseSegments(profile, probe);
                state = DownloadState.create(task, probe, segmentCount);
                preparePartialFile(temp, state);
                state.persist(stateFile, true);
            }

            ProgressTracker tracker = new ProgressTracker(task, profile, control, state.totalBytes, state.downloaded());
            tracker.setStrategy(state.segments.size(), state.rangeSupported);
            tracker.reportState(DownloadStore.STATUS_DOWNLOADING, tracker.strategy, state, null, true);
            notifyTask(task, "下载中 · " + tracker.strategy,
                    percent(tracker.downloaded.get(), tracker.totalBytes), tracker.downloaded.get(), tracker.totalBytes, true, false);

            if (state.rangeSupported && state.totalBytes > 0L) {
                downloadRanged(task, profile, state, temp, stateFile, control, tracker);
            } else {
                downloadSingle(task, profile, state, temp, stateFile, control, tracker);
            }
            control.check();
            Uri uri = publish(task, temp, control);
            tracker.forceReport(DownloadStore.STATUS_COMPLETED, "已完成", state, uri.toString());
            notifyTask(task, "已完成", 100, tracker.downloaded.get(), tracker.totalBytes, false, false);
            completed = true;
        } catch (Paused paused) {
            DownloadState state = DownloadState.load(stateFile);
            DownloadStore.Item current = store.get(task.id);
            long downloaded = state == null ? (current == null ? 0L : current.downloadedBytes) : state.downloaded();
            long total = state == null ? (current == null ? 0L : current.totalBytes) : state.totalBytes;
            int segments = state == null ? (current == null ? 0 : current.segmentCount) : state.segments.size();
            boolean ranged = state != null ? state.rangeSupported : current != null && current.rangeSupported;
            if (state != null) state.persist(stateFile, true);
            DownloadMemoryPolicy.Plan plan = DownloadMemoryPolicy.plan(this, task.mode, total);
            store.updateAdaptiveTelemetry(task.id, DownloadStore.STATUS_PAUSED, paused.reason,
                    downloaded, total, 0L, null, segments, plan.bufferBytes, plan.memoryBudgetBytes,
                    ranged, 0L, current == null ? 0 : current.retryCount);
            notifyTask(task, paused.reason, percent(downloaded, total), downloaded, total, false, true);
        } catch (Cancelled ignored) {
            cancelled = true;
            DownloadStore.Item current = store.get(task.id);
            long total = current == null ? 0L : current.totalBytes;
            store.updateAdaptive(task.id, DownloadStore.STATUS_CANCELLED, "已取消", 0L, total, 0L, null);
            notifyTask(task, "已取消", 0, 0L, total, false, false);
        } catch (Throwable error) {
            String reason = safeMessage(error);
            DownloadState state = DownloadState.load(stateFile);
            if (state != null) state.persist(stateFile, true);
            DownloadStore.Item current = store.get(task.id);
            long downloaded = state == null ? (current == null ? 0L : current.downloadedBytes) : state.downloaded();
            long total = state == null ? (current == null ? 0L : current.totalBytes) : state.totalBytes;
            int retries = current == null ? 1 : current.retryCount + 1;
            DownloadMemoryPolicy.Plan plan = DownloadMemoryPolicy.plan(this, task.mode, total);
            store.updateAdaptiveTelemetry(task.id, DownloadStore.STATUS_FAILED, reason, downloaded, total, 0L,
                    null, state == null ? 0 : state.segments.size(), plan.bufferBytes, plan.memoryBudgetBytes,
                    state != null && state.rangeSupported, 0L, retries);
            notifyTask(task, "失败 · " + reason, percent(downloaded, total), downloaded, total, false, true);
        } finally {
            CONTROLS.remove(Long.valueOf(task.id));
            if (locks != null) locks.release();
            if (completed || cancelled) {
                deleteQuietly(temp);
                deleteQuietly(stateFile);
            }
        }
    }

    private void waitForConstraints(Task task, Control control) throws Cancelled, Paused {
        while (true) {
            control.check();
            String reason = constraintReason(task);
            if (reason.length() == 0) return;
            DownloadStore.Item current = store.get(task.id);
            long downloaded = current == null ? 0L : current.downloadedBytes;
            long total = current == null ? 0L : current.totalBytes;
            store.updateAdaptive(task.id, DownloadStore.STATUS_WAITING, reason, downloaded, total, 0L, null);
            notifyTask(task, reason, percent(downloaded, total), downloaded, total, true, false);
            for (int i = 0; i < 10; i++) {
                control.check();
                SystemClock.sleep(1000L);
            }
        }
    }

    private String constraintReason(Task task) {
        try {
            ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (manager == null) return "等待网络";
            Network network = manager.getActiveNetwork();
            NetworkCapabilities caps = manager.getNetworkCapabilities(network);
            if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return "等待网络";
            if (task.wifiOnly && !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)) return "等待非计费网络";
            if (!task.allowRoaming) {
                if (Build.VERSION.SDK_INT >= 28) {
                    if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_ROAMING)) return "等待非漫游网络";
                } else {
                    NetworkInfo info = manager.getActiveNetworkInfo();
                    if (info != null && info.isRoaming()) return "等待非漫游网络";
                }
            }
            if (task.chargingOnly) {
                BatteryManager battery = (BatteryManager) getSystemService(BATTERY_SERVICE);
                if (battery == null || !battery.isCharging()) return "等待充电";
            }
            return "";
        } catch (RuntimeException error) { return "等待网络"; }
    }

    private Probe probe(Task task, Control control) throws Exception {
        HttpURLConnection connection = null;
        InputStream input = null;
        try {
            connection = open(task, task.url, "bytes=0-0", 15000, 20000);
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code);
            control.check();
            boolean range = code == HttpURLConnection.HTTP_PARTIAL;
            long[] contentRange = range ? parseContentRange(connection.getHeaderField("Content-Range")) : null;
            if (range && (contentRange == null || contentRange[0] != 0L || contentRange[1] != 0L))
                throw new IllegalStateException("服务器返回了无效的分段探测响应");
            long total = range ? contentRange[2] : connection.getContentLengthLong();
            input = connection.getInputStream();
            input.read();
            return new Probe(connection.getURL().toString(), total, range && total > 0L,
                    value(connection.getHeaderField("ETag")), value(connection.getHeaderField("Last-Modified")));
        } finally {
            closeQuietly(input);
            if (connection != null) connection.disconnect();
        }
    }

    private int chooseSegments(Profile profile, Probe probe) {
        if (!probe.rangeSupported || probe.totalBytes <= profile.minSegmentBytes) return 1;
        long useful = Math.max(1L, probe.totalBytes / profile.minSegmentBytes);
        return (int) Math.max(1L, Math.min((long) profile.maxSegments, useful));
    }

    private void preparePartialFile(File temp, DownloadState state) throws Exception {
        File parent = temp.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IllegalStateException("无法创建临时下载目录");
        RandomAccessFile allocator = new RandomAccessFile(temp, "rw");
        try {
            if (state.totalBytes > 0L) allocator.setLength(state.totalBytes);
            else allocator.setLength(0L);
        } finally { allocator.close(); }
    }

    private void downloadRanged(final Task task, final Profile profile, final DownloadState state, final File temp,
                                final File stateFile, final Control control, final ProgressTracker tracker) throws Exception {
        final AtomicBoolean abort = new AtomicBoolean(false);
        final RateLimiter limiter = new RateLimiter(profile.maxBytesPerSecond);
        int incomplete = state.incompleteCount();
        if (incomplete == 0) return;
        int workers = Math.max(1, Math.min(profile.maxSegments, incomplete));
        int running = Math.max(1, activeTasks.get());
        int cores = Math.max(1, Runtime.getRuntime().availableProcessors());
        if (profile.extreme) {
            int globalConnectionBudget = Math.max(32, Math.min(96, cores * 8));
            workers = Math.min(workers, Math.max(8, globalConnectionBudget / running));
        } else if (!profile.powerSave) {
            int globalConnectionBudget = Math.max(12, Math.min(48, cores * 4));
            workers = Math.min(workers, Math.max(4, globalConnectionBudget / running));
        }
        final AtomicReference<Throwable> rootFailure = new AtomicReference<Throwable>();
        ExecutorService segmentPool = Executors.newFixedThreadPool(workers);
        List<Future<?>> futures = new ArrayList<Future<?>>();
        for (int i = 0; i < state.segments.size(); i++) {
            final int index = i;
            if (state.segmentComplete(index)) continue;
            futures.add(segmentPool.submit(new Runnable() {
                @Override public void run() {
                    try {
                        setCurrentThreadPriority(profile.threadPriority);
                        downloadSegment(task, profile, state, index, temp, stateFile, control, abort, limiter, tracker);
                    } catch (Throwable error) {
                        if (!(error instanceof Cancelled) || !abort.get()) rootFailure.compareAndSet(null, error);
                        abort.set(true);
                        throw new RuntimeException(error);
                    }
                }
            }));
        }
        Throwable failure = null;
        try {
            for (Future<?> future : futures) {
                try { future.get(); }
                catch (ExecutionException error) { if (failure == null) failure = error.getCause(); }
            }
        } finally {
            if (failure != null || control.cancelled.get() || control.paused.get()) {
                abort.set(true);
                for (Future<?> future : futures) future.cancel(true);
            }
            segmentPool.shutdownNow();
            state.persist(stateFile, true);
        }
        control.check();
        Throwable root = rootFailure.get();
        if (root != null) failure = root;
        if (failure != null) {
            if (failure instanceof RuntimeException && failure.getCause() != null) failure = failure.getCause();
            if (failure instanceof Paused) throw (Paused) failure;
            if (failure instanceof Cancelled) throw (Cancelled) failure;
            if (failure instanceof Exception) throw (Exception) failure;
            throw new IllegalStateException(safeMessage(failure));
        }
        if (state.downloaded() != state.totalBytes) throw new EOFException("下载数据不完整");
    }

    private void downloadSegment(Task task, Profile profile, DownloadState state, int index, File temp,
                                 File stateFile, Control control, AtomicBoolean abort, RateLimiter limiter,
                                 ProgressTracker tracker) throws Exception {
        int attempts = 0;
        while (!state.segmentComplete(index)) {
            control.check();
            if (abort.get()) throw new Cancelled();
            long cursor = state.segmentCursor(index);
            long end = state.segmentEnd(index);
            HttpURLConnection connection = null;
            InputStream input = null;
            RandomAccessFile output = null;
            try {
                connection = open(task, state.resolvedUrl, "bytes=" + cursor + "-" + end,
                        profile.connectTimeoutMs, profile.readTimeoutMs);
                int code = connection.getResponseCode();
                if (code != HttpURLConnection.HTTP_PARTIAL) throw new IllegalStateException("服务器拒绝分段：HTTP " + code);
                long[] contentRange = parseContentRange(connection.getHeaderField("Content-Range"));
                if (contentRange == null || contentRange[0] != cursor || contentRange[1] > end ||
                        (state.totalBytes > 0L && contentRange[2] != state.totalBytes))
                    throw new IllegalStateException("服务器返回了不匹配的 Content-Range");
                input = connection.getInputStream();
                output = new RandomAccessFile(temp, "rw");
                output.seek(cursor);
                byte[] buffer = new byte[profile.bufferBytes];
                int read;
                while (!state.segmentComplete(index) &&
                        (read = input.read(buffer, 0, (int) Math.min((long) buffer.length, state.remaining(index)))) != -1) {
                    control.check();
                    if (abort.get()) throw new Cancelled();
                    output.write(buffer, 0, read);
                    state.advance(index, read);
                    tracker.add(read, state, stateFile);
                    limiter.afterBytes(read);
                }
                if (!state.segmentComplete(index)) throw new EOFException("连接提前结束");
            } catch (Paused paused) { throw paused;
            } catch (Cancelled cancelled) { throw cancelled;
            } catch (Exception error) {
                attempts++;
                tracker.retryCount.incrementAndGet();
                if (attempts > profile.retries) throw error;
                SystemClock.sleep(300L * attempts);
            } finally {
                closeQuietly(input);
                closeQuietly(output);
                if (connection != null) connection.disconnect();
            }
        }
    }

    private void downloadSingle(Task task, Profile profile, DownloadState state, File temp, File stateFile,
                                Control control, ProgressTracker tracker) throws Exception {
        Segment segment = state.segments.get(0);
        boolean canResume = state.rangeSupported && segment.cursor > segment.start;
        if (!state.rangeSupported && segment.cursor > 0L) {
            segment.cursor = 0L;
            tracker.reset(0L);
            preparePartialFile(temp, state);
            state.persist(stateFile, true);
        }
        RateLimiter limiter = new RateLimiter(profile.maxBytesPerSecond);
        Exception last = null;
        for (int attempt = 0; attempt <= profile.retries; attempt++) {
            control.check();
            if (!state.rangeSupported && segment.cursor > 0L) {
                segment.cursor = 0L;
                tracker.reset(0L);
                preparePartialFile(temp, state);
                state.persist(stateFile, true);
            }
            HttpURLConnection connection = null;
            InputStream input = null;
            RandomAccessFile output = null;
            try {
                long cursor = segment.cursor;
                String range = canResume && cursor > 0L ? "bytes=" + cursor + "-" : null;
                connection = open(task, state.resolvedUrl, range, profile.connectTimeoutMs, profile.readTimeoutMs);
                int code = connection.getResponseCode();
                if (range != null && code == HttpURLConnection.HTTP_PARTIAL) {
                    long[] contentRange = parseContentRange(connection.getHeaderField("Content-Range"));
                    if (contentRange == null || contentRange[0] != cursor ||
                            (state.totalBytes > 0L && contentRange[2] != state.totalBytes))
                        throw new IllegalStateException("服务器返回了不匹配的续传范围");
                }
                if (range != null && code != HttpURLConnection.HTTP_PARTIAL) {
                    segment.cursor = 0L;
                    tracker.reset(0L);
                    cursor = 0L;
                    closeQuietly(connection.getInputStream());
                    connection.disconnect();
                    connection = open(task, state.resolvedUrl, null, profile.connectTimeoutMs, profile.readTimeoutMs);
                    code = connection.getResponseCode();
                }
                if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code);
                long content = connection.getContentLengthLong();
                if (state.totalBytes <= 0L && content > 0L) {
                    state.totalBytes = cursor + content;
                    segment.end = state.totalBytes - 1L;
                    tracker.totalBytes = state.totalBytes;
                }
                input = connection.getInputStream();
                output = new RandomAccessFile(temp, "rw");
                output.seek(cursor);
                byte[] buffer = new byte[profile.bufferBytes];
                int read;
                while (true) {
                    long remaining = state.totalBytes > 0L ? state.totalBytes - segment.cursor : buffer.length;
                    if (state.totalBytes > 0L && remaining <= 0L) break;
                    int request = (int) Math.min((long) buffer.length, Math.max(1L, remaining));
                    read = input.read(buffer, 0, request);
                    if (read == -1) break;
                    control.check();
                    output.write(buffer, 0, read);
                    state.advance(0, read);
                    tracker.add(read, state, stateFile);
                    limiter.afterBytes(read);
                }
                if (state.totalBytes > 0L && state.downloaded() != state.totalBytes)
                    throw new EOFException("下载数据不完整");
                state.persist(stateFile, true);
                return;
            } catch (Paused paused) { throw paused;
            } catch (Cancelled cancelled) { throw cancelled;
            } catch (Exception error) {
                last = error;
                tracker.retryCount.incrementAndGet();
                if (attempt >= profile.retries) throw error;
                canResume = state.rangeSupported;
                SystemClock.sleep(400L * (attempt + 1L));
            } finally {
                closeQuietly(input);
                closeQuietly(output);
                if (connection != null) connection.disconnect();
            }
        }
        if (last != null) throw last;
    }

    private Uri publish(Task task, File temp, Control control) throws Exception {
        control.check();
        ContentResolver resolver = getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, task.filename);
        values.put(MediaStore.MediaColumns.MIME_TYPE, task.mime.length() == 0 ? "application/octet-stream" : task.mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Median");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("无法创建下载文件");
        InputStream input = null;
        OutputStream output = null;
        try {
            input = new BufferedInputStream(new FileInputStream(temp), 256 * 1024);
            OutputStream rawOutput = resolver.openOutputStream(uri, "w");
            if (rawOutput == null) throw new IllegalStateException("无法写入下载目录");
            output = new BufferedOutputStream(rawOutput, 256 * 1024);
            byte[] buffer = new byte[256 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                control.check();
                output.write(buffer, 0, read);
            }
            output.flush();
            values.clear();
            values.put(MediaStore.MediaColumns.IS_PENDING, 0);
            values.put(MediaStore.MediaColumns.SIZE, temp.length());
            resolver.update(uri, values, null, null);
            return uri;
        } catch (Throwable error) {
            resolver.delete(uri, null, null);
            if (error instanceof Paused) throw (Paused) error;
            if (error instanceof Cancelled) throw (Cancelled) error;
            if (error instanceof Exception) throw (Exception) error;
            throw new IllegalStateException(safeMessage(error));
        } finally {
            closeQuietly(input);
            closeQuietly(output);
        }
    }

    private HttpURLConnection open(Task task, String url, String range, int connectTimeout, int readTimeout) throws Exception {
        URL initial = NetworkSecurity.parseHttpUrl(url);
        URL original = NetworkSecurity.parseHttpUrl(task.url);
        URL current = initial;
        for (int redirects = 0; redirects <= NetworkSecurity.MAX_REDIRECTS; redirects++) {
            if (task.publicOnly && NetworkSecurity.isLocalOrPrivateHost(NetworkSecurity.normalizedHost(current)))
                throw new IllegalArgumentException("本地或私有网络下载目标已拒绝");
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(connectTimeout);
            connection.setReadTimeout(readTimeout);
            connection.setUseCaches(false);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept-Encoding", "identity");
            if (task.userAgent.length() > 0) connection.setRequestProperty("User-Agent", task.userAgent);
            if (range != null) connection.setRequestProperty("Range", range);
            boolean sameOrigin = NetworkSecurity.sameOrigin(original, current);
            if (sameOrigin && task.cookie.length() > 0) connection.setRequestProperty("Cookie", task.cookie);
            for (Map.Entry<String, String> header : task.headers.entrySet()) {
                if (!NetworkSecurity.validHeader(header.getKey(), header.getValue()) ||
                        NetworkSecurity.isForbiddenRequestHeader(header.getKey())) continue;
                if (!sameOrigin && NetworkSecurity.isCredentialHeader(header.getKey())) continue;
                connection.setRequestProperty(header.getKey(), header.getValue());
            }
            int status = connection.getResponseCode();
            if (!NetworkSecurity.isRedirect(status)) return connection;
            if (redirects == NetworkSecurity.MAX_REDIRECTS) {
                connection.disconnect();
                throw new IllegalStateException("重定向次数过多");
            }
            URL next = NetworkSecurity.resolveRedirect(current, connection.getHeaderField("Location"), false);
            connection.disconnect();
            current = next;
        }
        throw new IllegalStateException("重定向次数过多");
    }

    private File partialDirectory() {
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = new File(getCacheDir(), "downloads");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private static String safeTaskId(long id) { return id == Long.MIN_VALUE ? "min" : Long.toString(Math.abs(id)); }
    private File partialFile(long id) { return new File(partialDirectory(), "median-" + safeTaskId(id) + ".part"); }
    private File stateFile(long id) { return new File(partialDirectory(), "median-" + safeTaskId(id) + ".state"); }

    private void deletePartialFiles(long id) {
        deleteQuietly(partialFile(id));
        deleteQuietly(stateFile(id));
    }

    private Locks acquireLocks(Profile profile) {
        Locks locks = new Locks();
        if (!profile.extreme) return locks;
        try {
            PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
            if (power != null) {
                locks.wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Median:AdaptiveDownload");
                locks.wakeLock.setReferenceCounted(false);
                locks.wakeLock.acquire(6L * 60L * 60L * 1000L);
            }
        } catch (RuntimeException ignored) {}
        try {
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi != null) {
                int mode = Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                locks.wifiLock = wifi.createWifiLock(mode, "Median:AdaptiveDownloadWifi");
                locks.wifiLock.setReferenceCounted(false);
                locks.wifiLock.acquire();
            }
        } catch (RuntimeException ignored) {}
        return locks;
    }

    private void notifyTask(Task task, String text, int percent, long downloaded, long total,
                            boolean ongoing, boolean resumable) {
        if (notificationManager == null || task == null) return;
        notificationManager.notify(notificationId(task.id),
                buildNotification(task, text, percent, downloaded, total, ongoing, resumable));
    }

    private Notification buildNotification(Task task, String text, int percent, long downloaded, long total,
                                           boolean ongoing, boolean resumable) {
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        Intent open = new Intent(this, DownloadCenterActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(this, notificationId(task.id), open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        builder.setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(task.filename)
                .setContentText(text)
                .setContentIntent(content)
                .setOnlyAlertOnce(true)
                .setOngoing(ongoing)
                .setCategory(Notification.CATEGORY_PROGRESS)
                .setVisibility(Notification.VISIBILITY_PRIVATE);
        if (total > 0L) builder.setProgress(100, Math.max(0, Math.min(100, percent)), false);
        else if (ongoing) builder.setProgress(0, 0, true);
        if (ongoing) {
            builder.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause, "暂停",
                    serviceAction(task.id, ACTION_PAUSE, 1)).build());
            builder.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "取消",
                    serviceAction(task.id, ACTION_CANCEL, 2)).build());
        } else if (resumable) {
            builder.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_play, "继续",
                    serviceAction(task.id, ACTION_RESUME, 3)).build());
            builder.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "取消",
                    serviceAction(task.id, ACTION_CANCEL, 4)).build());
            builder.setAutoCancel(false);
        } else builder.setAutoCancel(true);
        return builder.build();
    }

    private PendingIntent serviceAction(long id, String action, int salt) {
        Intent intent = new Intent(this, AdaptiveDownloadService.class);
        intent.setAction(action);
        intent.putExtra(EXTRA_ID, id);
        return PendingIntent.getService(this, notificationId(id) * 10 + salt, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static int notificationId(long id) { return 7200 + (int) Math.abs(id % 100000L); }
    private static int percent(long downloaded, long total) {
        return total > 0L ? (int) Math.max(0L, Math.min(100L, downloaded * 100L / total)) : 0;
    }

    private static long[] parseContentRange(String value) {
        if (value == null) return null;
        String normalized = value.trim();
        if (!normalized.regionMatches(true, 0, "bytes ", 0, 6)) return null;
        int dash = normalized.indexOf('-', 6);
        int slash = normalized.indexOf('/', dash + 1);
        if (dash <= 6 || slash <= dash + 1 || slash + 1 >= normalized.length()) return null;
        try {
            long start = Long.parseLong(normalized.substring(6, dash).trim());
            long end = Long.parseLong(normalized.substring(dash + 1, slash).trim());
            long total = Long.parseLong(normalized.substring(slash + 1).trim());
            if (start < 0L || end < start || total <= end) return null;
            return new long[] { start, end, total };
        } catch (NumberFormatException ignored) { return null; }
    }

    private static void setCurrentThreadPriority(int priority) {
        try { Process.setThreadPriority(Process.myTid(), priority); }
        catch (RuntimeException ignored) {}
    }

    private static String safeMessage(Throwable error) {
        if (error == null) return "未知错误";
        String message = error.getMessage();
        if (message == null || message.trim().length() == 0) message = error.getClass().getSimpleName();
        if (message.length() > 140) message = message.substring(0, 140);
        return message;
    }

    private static void closeQuietly(java.io.Closeable closeable) {
        if (closeable != null) try { closeable.close(); } catch (Exception ignored) {}
    }

    private static void deleteQuietly(File file) {
        if (file != null && file.exists()) try { file.delete(); } catch (RuntimeException ignored) {}
    }

    private static String value(String value) { return value == null ? "" : value; }

    private final class ProgressTracker {
        final Task task;
        final Profile profile;
        final Control control;
        final AtomicLong downloaded = new AtomicLong();
        final AtomicInteger retryCount = new AtomicInteger();
        volatile long totalBytes;
        volatile String strategy = "";
        private long lastReportAt = SystemClock.elapsedRealtime();
        private long lastReportBytes;
        private final AtomicLong nextReportAt = new AtomicLong(lastReportAt + 900L);
        private final AtomicLong nextStatePersistAt = new AtomicLong(lastReportAt + 2000L);

        ProgressTracker(Task task, Profile profile, Control control, long totalBytes, long initialDownloaded) {
            this.task = task;
            this.profile = profile;
            this.control = control;
            this.totalBytes = Math.max(0L, totalBytes);
            this.downloaded.set(Math.max(0L, initialDownloaded));
            this.lastReportBytes = this.downloaded.get();
        }

        void setStrategy(int segments, boolean ranged) {
            if (profile.extreme) strategy = "极限 · " + segments + " 分段 · " + DownloadMemoryPolicy.humanBytes(profile.memoryBudgetBytes) + " 内存预算";
            else if (profile.powerSave) strategy = "低功耗 · 单连接 · 2 MB/s 上限";
            else strategy = "标准 · " + (ranged ? segments + " 分段" : "单连接") + " · 100 Mbps 上限";
        }

        void reset(long bytes) {
            downloaded.set(Math.max(0L, bytes));
            lastReportBytes = downloaded.get();
            lastReportAt = SystemClock.elapsedRealtime();
        }

        void add(int count, DownloadState state, File stateFile) throws Cancelled, Paused {
            control.check();
            downloaded.addAndGet(count);
            long now = SystemClock.elapsedRealtime();
            long persistAt = nextStatePersistAt.get();
            if (now >= persistAt && nextStatePersistAt.compareAndSet(persistAt, now + 2000L)) {
                state.persist(stateFile, false);
            }
            long reportAt = nextReportAt.get();
            if (now >= reportAt && nextReportAt.compareAndSet(reportAt, now + 900L)) {
                reportState(DownloadStore.STATUS_DOWNLOADING, strategy, state, null, false);
            }
        }

        synchronized void reportState(String status, String reason, DownloadState state, String uri, boolean force) {
            long now = SystemClock.elapsedRealtime();
            if (!force && now - lastReportAt < 1000L) return;
            long current = downloaded.get();
            long elapsed = Math.max(1L, now - lastReportAt);
            long speed = Math.max(0L, (current - lastReportBytes) * 1000L / elapsed);
            long eta = speed > 0L && totalBytes > current ? (totalBytes - current) / speed : 0L;
            store.updateAdaptiveTelemetry(task.id, status, reason, current, totalBytes, speed, uri,
                    state.segments.size(), profile.bufferBytes, profile.memoryBudgetBytes,
                    state.rangeSupported, eta, retryCount.get());
            int pct = percent(current, totalBytes);
            notifyTask(task, "下载中 · " + pct + "% · " + humanSpeed(speed), pct, current, totalBytes, true, false);
            lastReportAt = now;
            lastReportBytes = current;
        }

        void forceReport(String status, String reason, DownloadState state, String uri) {
            reportState(status, reason, state, uri, true);
            store.updateAdaptiveTelemetry(task.id, status, reason, downloaded.get(), totalBytes, 0L, uri,
                    state.segments.size(), profile.bufferBytes, profile.memoryBudgetBytes,
                    state.rangeSupported, 0L, retryCount.get());
        }
    }

    private static String humanSpeed(long bytesPerSecond) {
        if (bytesPerSecond < 1024L) return bytesPerSecond + " B/s";
        if (bytesPerSecond < 1024L * 1024L) return String.format(Locale.US, "%.1f KB/s", bytesPerSecond / 1024d);
        return String.format(Locale.US, "%.1f MB/s", bytesPerSecond / (1024d * 1024d));
    }

    private static final class Task {
        long id;
        String url;
        String filename;
        String mime;
        String userAgent;
        String cookie;
        String mode;
        boolean wifiOnly;
        boolean allowRoaming;
        boolean chargingOnly;
        boolean publicOnly;
        final Map<String, String> headers = new HashMap<String, String>();

        static Task fromIntent(Intent intent) {
            Task task = new Task();
            task.id = intent.getLongExtra(EXTRA_ID, 0L);
            task.url = value(intent.getStringExtra(EXTRA_URL));
            task.filename = value(intent.getStringExtra(EXTRA_NAME));
            task.mime = value(intent.getStringExtra(EXTRA_MIME));
            task.userAgent = value(intent.getStringExtra(EXTRA_USER_AGENT));
            task.cookie = value(intent.getStringExtra(EXTRA_COOKIE));
            task.mode = value(intent.getStringExtra(EXTRA_MODE));
            task.wifiOnly = intent.getBooleanExtra(EXTRA_WIFI_ONLY, false);
            task.allowRoaming = intent.getBooleanExtra(EXTRA_ALLOW_ROAMING, false);
            task.chargingOnly = intent.getBooleanExtra(EXTRA_CHARGING_ONLY, false);
            task.publicOnly = intent.getBooleanExtra(EXTRA_PUBLIC_ONLY, false);
            parseHeaders(value(intent.getStringExtra(EXTRA_HEADERS)), task.headers);
            return task;
        }

        static Task fromStore(Context context, DownloadStore.Item item) {
            Task task = new Task();
            task.id = item.id;
            task.url = value(item.url);
            task.filename = value(item.filename);
            task.mime = value(item.mime);
            task.userAgent = value(item.userAgent);
            try {
                String cookie = CookieManager.getInstance().getCookie(task.url);
                task.cookie = value(cookie);
            } catch (RuntimeException ignored) { task.cookie = ""; }
            task.mode = value(item.mode);
            task.wifiOnly = item.wifiOnly;
            task.allowRoaming = item.allowRoaming;
            task.chargingOnly = item.chargingOnly;
            task.publicOnly = item.publicOnly;
            parseHeaders(item.headersJson, task.headers);
            return task;
        }

        private static void parseHeaders(String json, Map<String, String> target) {
            try {
                JSONObject object = new JSONObject(value(json));
                Iterator<String> keys = object.keys();
                while (keys.hasNext()) {
                    String name = keys.next();
                    String headerValue = object.optString(name, "");
                    if (!NetworkSecurity.validHeader(name, headerValue) || NetworkSecurity.isForbiddenRequestHeader(name) ||
                            NetworkSecurity.isCredentialHeader(name) || "user-agent".equalsIgnoreCase(name)) continue;
                    target.put(name, headerValue);
                }
            } catch (Exception ignored) {}
        }
    }

    private static final class Probe {
        final String resolvedUrl;
        final long totalBytes;
        final boolean rangeSupported;
        final String etag;
        final String lastModified;
        Probe(String resolvedUrl, long totalBytes, boolean rangeSupported, String etag, String lastModified) {
            this.resolvedUrl = resolvedUrl;
            this.totalBytes = totalBytes;
            this.rangeSupported = rangeSupported;
            this.etag = etag;
            this.lastModified = lastModified;
        }
    }

    private static final class Profile {
        final int maxSegments;
        final int bufferBytes;
        final long memoryBudgetBytes;
        final long maxBytesPerSecond;
        final int threadPriority;
        final int retries;
        final int connectTimeoutMs;
        final int readTimeoutMs;
        final long minSegmentBytes;
        final boolean extreme;
        final boolean powerSave;

        Profile(int maxSegments, int bufferBytes, long memoryBudgetBytes, long maxBytesPerSecond,
                int threadPriority, int retries, int connectTimeoutMs, int readTimeoutMs,
                long minSegmentBytes, boolean extreme, boolean powerSave) {
            this.maxSegments = maxSegments;
            this.bufferBytes = bufferBytes;
            this.memoryBudgetBytes = memoryBudgetBytes;
            this.maxBytesPerSecond = maxBytesPerSecond;
            this.threadPriority = threadPriority;
            this.retries = retries;
            this.connectTimeoutMs = connectTimeoutMs;
            this.readTimeoutMs = readTimeoutMs;
            this.minSegmentBytes = minSegmentBytes;
            this.extreme = extreme;
            this.powerSave = powerSave;
        }

        static Profile from(String mode, DownloadMemoryPolicy.Plan plan) {
            if (DownloadMemoryPolicy.MODE_PERFORMANCE.equals(mode)) {
                return new Profile(plan.maxSegments, plan.bufferBytes, plan.memoryBudgetBytes, 0L,
                        Process.THREAD_PRIORITY_FOREGROUND, 6, 7000, 12000, 2L * MIB, true, false);
            }
            if (DownloadMemoryPolicy.MODE_POWER_SAVE.equals(mode)) {
                return new Profile(1, plan.bufferBytes, plan.memoryBudgetBytes, plan.maxBytesPerSecond,
                        Process.THREAD_PRIORITY_BACKGROUND, 2, 25000, 45000, 8L * MIB, false, true);
            }
            return new Profile(plan.maxSegments, plan.bufferBytes, plan.memoryBudgetBytes, plan.maxBytesPerSecond,
                    Process.THREAD_PRIORITY_MORE_FAVORABLE, 4, 12000, 22000, 4L * MIB, false, false);
        }
    }

    private static final class RateLimiter {
        final long bytesPerSecond;
        long startedAtNanos = SystemClock.elapsedRealtimeNanos();
        long bytes;
        RateLimiter(long bytesPerSecond) { this.bytesPerSecond = bytesPerSecond; }
        void afterBytes(int count) {
            if (bytesPerSecond <= 0L) return;
            synchronized (this) {
                bytes += count;
                long expected = bytes * 1_000_000_000L / bytesPerSecond;
                long elapsed = SystemClock.elapsedRealtimeNanos() - startedAtNanos;
                long sleepNanos = expected - elapsed;
                if (sleepNanos > 0L) {
                    try { Thread.sleep(sleepNanos / 1_000_000L, (int) (sleepNanos % 1_000_000L)); }
                    catch (InterruptedException error) { Thread.currentThread().interrupt(); }
                }
                if (SystemClock.elapsedRealtimeNanos() - startedAtNanos > 5_000_000_000L) {
                    startedAtNanos = SystemClock.elapsedRealtimeNanos();
                    bytes = 0L;
                }
            }
        }
    }

    private static final class Control {
        final AtomicBoolean cancelled = new AtomicBoolean(false);
        final AtomicBoolean paused = new AtomicBoolean(false);
        volatile String pauseReason = "已暂停";
        void cancel() { cancelled.set(true); }
        void pause(String reason) { pauseReason = value(reason); paused.set(true); }
        void check() throws Cancelled, Paused {
            if (cancelled.get()) throw new Cancelled();
            if (paused.get()) throw new Paused(pauseReason);
            if (Thread.currentThread().isInterrupted()) {
                if (paused.get()) throw new Paused(pauseReason);
                throw new Cancelled();
            }
        }
    }

    private static final class Cancelled extends Exception { private static final long serialVersionUID = 1L; }
    private static final class Paused extends Exception {
        private static final long serialVersionUID = 1L;
        final String reason;
        Paused(String reason) { this.reason = value(reason).length() == 0 ? "已暂停" : value(reason); }
    }

    private static final class Locks {
        PowerManager.WakeLock wakeLock;
        WifiManager.WifiLock wifiLock;
        void release() {
            try { if (wifiLock != null && wifiLock.isHeld()) wifiLock.release(); } catch (RuntimeException ignored) {}
            try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (RuntimeException ignored) {}
        }
    }

    private static final class Segment {
        long start;
        long end;
        volatile long cursor;
    }

    private static final class DownloadState {
        String originalUrl;
        String resolvedUrl;
        String etag;
        String lastModified;
        long totalBytes;
        boolean rangeSupported;
        final ArrayList<Segment> segments = new ArrayList<Segment>();
        private long lastPersistAt;

        static DownloadState create(Task task, Probe probe, int segmentCount) {
            DownloadState state = new DownloadState();
            state.originalUrl = task.url;
            state.resolvedUrl = probe.resolvedUrl;
            state.etag = probe.etag;
            state.lastModified = probe.lastModified;
            state.totalBytes = probe.totalBytes;
            state.rangeSupported = probe.rangeSupported;
            int count = probe.rangeSupported && probe.totalBytes > 0L ? Math.max(1, segmentCount) : 1;
            if (probe.totalBytes > 0L) {
                long chunk = (probe.totalBytes + count - 1L) / count;
                for (int i = 0; i < count; i++) {
                    Segment segment = new Segment();
                    segment.start = i * chunk;
                    segment.end = Math.min(probe.totalBytes - 1L, segment.start + chunk - 1L);
                    segment.cursor = segment.start;
                    if (segment.start <= segment.end) state.segments.add(segment);
                }
            } else {
                Segment segment = new Segment();
                segment.start = 0L;
                segment.end = Long.MAX_VALUE;
                segment.cursor = 0L;
                state.segments.add(segment);
            }
            return state;
        }

        boolean matches(Task task, Probe probe) {
            if (!value(originalUrl).equals(task.url)) return false;
            if (probe.totalBytes > 0L && totalBytes > 0L && probe.totalBytes != totalBytes) return false;
            if (value(etag).length() > 0 && value(probe.etag).length() > 0 && !etag.equals(probe.etag)) return false;
            if (value(lastModified).length() > 0 && value(probe.lastModified).length() > 0 && !lastModified.equals(probe.lastModified)) return false;
            if (rangeSupported != probe.rangeSupported) return false;
            resolvedUrl = probe.resolvedUrl;
            return segments.size() > 0;
        }

        long downloaded() {
            long total = 0L;
            for (Segment segment : segments) total += Math.max(0L, segment.cursor - segment.start);
            return total;
        }

        int incompleteCount() {
            int count = 0;
            for (Segment segment : segments) if (segment.cursor <= segment.end) count++;
            return count;
        }

        boolean segmentComplete(int index) { return segments.get(index).cursor > segments.get(index).end; }
        long segmentCursor(int index) { return segments.get(index).cursor; }
        long segmentEnd(int index) { return segments.get(index).end; }
        long remaining(int index) { return Math.max(0L, segments.get(index).end - segments.get(index).cursor + 1L); }
        void advance(int index, int count) { segments.get(index).cursor += Math.max(0, count); }

        synchronized void persist(File file, boolean force) {
            long now = SystemClock.elapsedRealtime();
            if (!force && now - lastPersistAt < 2000L) return;
            FileOutputStream output = null;
            try {
                JSONObject object = new JSONObject();
                object.put("version", 1);
                object.put("originalUrl", originalUrl);
                object.put("resolvedUrl", resolvedUrl);
                object.put("etag", etag);
                object.put("lastModified", lastModified);
                object.put("totalBytes", totalBytes);
                object.put("rangeSupported", rangeSupported);
                JSONArray array = new JSONArray();
                for (Segment segment : segments) {
                    JSONObject item = new JSONObject();
                    item.put("start", segment.start);
                    item.put("end", segment.end);
                    item.put("cursor", segment.cursor);
                    array.put(item);
                }
                object.put("segments", array);
                File temp = new File(file.getAbsolutePath() + ".tmp");
                output = new FileOutputStream(temp, false);
                output.write(object.toString().getBytes("UTF-8"));
                if (force) output.getFD().sync();
                output.close();
                output = null;
                if (file.exists() && !file.delete()) return;
                if (!temp.renameTo(file)) temp.delete();
                lastPersistAt = now;
            } catch (Exception ignored) {
            } finally { closeQuietly(output); }
        }

        static DownloadState load(File file) {
            if (file == null || !file.isFile() || file.length() <= 0L || file.length() > 512L * 1024L) return null;
            FileInputStream input = null;
            try {
                input = new FileInputStream(file);
                byte[] data = new byte[(int) file.length()];
                int offset = 0;
                while (offset < data.length) {
                    int read = input.read(data, offset, data.length - offset);
                    if (read < 0) break;
                    offset += read;
                }
                JSONObject object = new JSONObject(new String(data, 0, offset, "UTF-8"));
                if (object.optInt("version", 0) != 1) return null;
                DownloadState state = new DownloadState();
                state.originalUrl = object.optString("originalUrl", "");
                state.resolvedUrl = object.optString("resolvedUrl", state.originalUrl);
                state.etag = object.optString("etag", "");
                state.lastModified = object.optString("lastModified", "");
                state.totalBytes = object.optLong("totalBytes", 0L);
                state.rangeSupported = object.optBoolean("rangeSupported", false);
                JSONArray array = object.optJSONArray("segments");
                if (array == null) return null;
                for (int i = 0; i < array.length(); i++) {
                    JSONObject item = array.optJSONObject(i);
                    if (item == null) continue;
                    Segment segment = new Segment();
                    segment.start = item.optLong("start", 0L);
                    segment.end = item.optLong("end", -1L);
                    segment.cursor = Math.max(segment.start, item.optLong("cursor", segment.start));
                    if (segment.end != Long.MAX_VALUE) segment.cursor = Math.min(segment.end + 1L, segment.cursor);
                    if (segment.end >= segment.start || segment.end == Long.MAX_VALUE) state.segments.add(segment);
                }
                return state.segments.size() == 0 ? null : state;
            } catch (Exception ignored) { return null;
            } finally { closeQuietly(input); }
        }
    }
}
