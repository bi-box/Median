package com.xinyv.median;

import android.net.Uri;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Bounded, metadata-only media URL index populated from requests and DOM media elements. */
final class MediaResourceSniffer {
    static final class Resource {
        String url;
        String mime;
        String kind;
        String pageHost;
        long seenAt;
    }

    private static final int MAX_ITEMS = 80;
    private final LinkedHashMap<String, Resource> items = new LinkedHashMap<String, Resource>();
    private String pageUrl = "";

    synchronized void beginPage(String url) {
        String next = value(url);
        if (next.equals(pageUrl)) return;
        pageUrl = next;
        items.clear();
    }

    void observe(Uri uri, Map<String, String> requestHeaders, String pageHost) {
        if (uri == null) return;
        String url = uri.toString();
        String mime = header(requestHeaders, "Accept");
        addIfMedia(url, mime, pageHost);
    }

    void observe(String url, String mime, String pageHost) {
        addIfMedia(url, mime, pageHost);
    }

    synchronized List<Resource> getAll() {
        ArrayList<Resource> result = new ArrayList<Resource>();
        for (Resource source : items.values()) result.add(copy(source));
        return result;
    }

    synchronized int size() { return items.size(); }

    private synchronized void addIfMedia(String url, String declaredMime, String pageHost) {
        if (url == null || url.length() > 8192 || (!url.startsWith("https://") && !url.startsWith("http://"))) return;
        String lower = url.toLowerCase(Locale.US);
        String mime = declaredMime == null ? "" : declaredMime.toLowerCase(Locale.US);
        String kind = kindOf(lower, mime);
        if (kind.length() == 0) return;
        Resource existing = items.remove(url);
        Resource item = existing == null ? new Resource() : existing;
        item.url = url;
        item.kind = kind;
        item.mime = normalizedMime(lower, mime, kind);
        item.pageHost = value(pageHost);
        item.seenAt = System.currentTimeMillis();
        items.put(url, item);
        while (items.size() > MAX_ITEMS) {
            String first = items.keySet().iterator().next();
            items.remove(first);
        }
    }

    private static String kindOf(String url, String mime) {
        if (mime.contains("application/vnd.apple.mpegurl") || mime.contains("application/x-mpegurl") || hasExtension(url, ".m3u8")) return "HLS 流";
        if (mime.contains("application/dash+xml") || hasExtension(url, ".mpd")) return "DASH 流";
        if (mime.contains("video/") || hasAny(url, ".mp4", ".webm", ".mkv", ".mov", ".m4v")) return "视频";
        if (mime.contains("audio/") || hasAny(url, ".mp3", ".m4a", ".aac", ".ogg", ".opus", ".flac", ".wav")) return "音频";
        return "";
    }

    private static String normalizedMime(String url, String mime, String kind) {
        int comma = mime.indexOf(',');
        if (comma >= 0) mime = mime.substring(0, comma);
        if (mime.startsWith("video/") || mime.startsWith("audio/") || mime.startsWith("application/")) return mime;
        if ("HLS 流".equals(kind)) return "application/vnd.apple.mpegurl";
        if ("DASH 流".equals(kind)) return "application/dash+xml";
        if (hasExtension(url, ".mp3")) return "audio/mpeg";
        if (hasExtension(url, ".m4a")) return "audio/mp4";
        if (hasExtension(url, ".webm")) return "video/webm";
        return "视频".equals(kind) ? "video/*" : "audio/*";
    }

    private static boolean hasAny(String url, String... extensions) {
        for (String extension : extensions) if (hasExtension(url, extension)) return true;
        return false;
    }

    private static boolean hasExtension(String url, String extension) {
        int query = url.indexOf('?');
        String path = query < 0 ? url : url.substring(0, query);
        return path.endsWith(extension) || path.contains(extension + "/");
    }

    private static String header(Map<String, String> headers, String name) {
        if (headers == null) return "";
        for (Map.Entry<String, String> entry : headers.entrySet()) if (name.equalsIgnoreCase(entry.getKey())) return value(entry.getValue());
        return "";
    }

    private static Resource copy(Resource source) {
        Resource item = new Resource();
        item.url = source.url;
        item.mime = source.mime;
        item.kind = source.kind;
        item.pageHost = source.pageHost;
        item.seenAt = source.seenAt;
        return item;
    }

    private static String value(String value) { return value == null ? "" : value; }
}
