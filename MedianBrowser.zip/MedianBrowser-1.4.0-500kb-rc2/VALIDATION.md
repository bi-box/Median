# Validation — Median Browser 1.4.0 500 KB RC1

## 已在当前环境完成

- 40 个生产 Java 文件通过词法、括号和字符串完整性检查。
- Android XML 资源全部通过解析。
- `NetworkSecurity` 使用 JDK 17 编译并通过独立自测。
- 用户脚本生成的完整 JavaScript 通过 Node 语法检查。
- 版本统一为 versionCode 42 / versionName `1.4.0-500kb-rc2`；compileSdk/targetSdk 为 36，minSdk 为 26。
- 聚焦版 `WebViewCompat`、`WebViewFeature`、`ScriptHandler` 和 Chromium boundary 接口完成源码编译。
- R8 release 收缩、单 DEX、资源稀疏编码、ZIP 对齐和 APK v2/v3 签名完成。
- APK ZIP 完整性、包名、版本、minSdk、targetSdk 和签名证书检查通过。
- 最终 DEX 保留 AndroidX-compatible facade、System WebView glue 字符串、boundary 接口和浏览器核心组件。
- 签名 APK 为 189,054 字节，低于 500 KiB 发行目标；构建脚本只报告体积状态。

执行源码静态检查：

```bash
./tools/static_checks.sh
```

执行 500 KB 签名 APK 构建：

```bash
ANDROID_SDK_ROOT=/path/to/sdk \
MEDIAN_KEYSTORE=/path/to/release.p12 \
MEDIAN_STOREPASS='...' \
MEDIAN_KEY_ALIAS='...' \
MEDIAN_KEYPASS='...' \
./tools/build_500kb_apk.sh
```

## 仍需外部完成

当前环境没有连接 Android 真机或模拟器，因此尚未证明：

- APK 安装、冷启动和页面渲染。
- 当前稳定 System WebView 与主要 OEM WebView 的 document-start 兼容性。
- 摄像头、麦克风、定位、下载和隐私窗口的端到端行为。
- Android 8–16 多机型长时间稳定性。
- 冷启动、PSS、耗电、下载吞吐、崩溃和 ANR 指标。
- Google Play 预发布报告及生产签名 AAB。

测试 APK 使用一次性测试证书，不得上传 Google Play。
