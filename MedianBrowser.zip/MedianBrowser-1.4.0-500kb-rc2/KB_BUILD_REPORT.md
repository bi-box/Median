# Median Browser 1.4.0 KB RC1 build report

## Result

- Signed APK size: **184,958 bytes** (approximately **180.6 KiB**)
- Previous debug APK: 1,553,120 bytes
- Reduction: approximately **88.1%**
- Package ID: `com.xinyv.median.kb`
- Version: `1.4.0-kb-rc1` (`versionCode 40`)
- Minimum Android: API 26 / Android 8.0
- Target and compile SDK: API 36
- Signature: disposable test certificate, APK Signature Scheme v2 and v3

## Functional preservation

The production AndroidX WebKit dependency was removed, not the document-start feature. Median now invokes the same Android System WebView support-library boundary through a small local compatibility layer. On WebView implementations that advertise `DOCUMENT_START_SCRIPT:1`, registration and removal use the native document-start path. Unsupported or incompatible WebView implementations fail closed, matching the hardened security posture.

R8 mapping confirms that the final DEX retains the ad blocker, password vault, user-script store, script values, filter subscriptions, download store, offline pages, media sniffer, site settings, private activity, download service, and document-start compatibility layer. The linked manifest retains all activities, service, provider, permissions, deep-link filters and private-process configuration.

## Verification completed

- All production Java sources compiled against Android API 36.
- R8 release shrinking, optimization and name minification completed.
- Single compressed DEX generated.
- APK ZIP integrity passed.
- AAPT package/version/minSdk/targetSdk inspection passed.
- APK Signature Scheme v2 and v3 verification passed.
- Boundary interface names, feature token and WebView glue entry point are present in final DEX.
- Static source checks and generated user-script JavaScript syntax checks passed.

## Remaining validation

This environment has no connected Android device or emulator. Installation, launch, WebView provider compatibility, downloads, camera/microphone/location prompts and long-session stability still require device testing before production rollout. The included APK is test-signed and must not be uploaded to Google Play.
