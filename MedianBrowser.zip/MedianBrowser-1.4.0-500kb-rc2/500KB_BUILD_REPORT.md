# Median Browser 1.4.0 500 KB RC1 build report

## Result

- Signed APK: **184,958 bytes** (approximately **180.6 KiB**)
- Hard budget: **512,000 bytes**
- Remaining budget: **327,042 bytes**
- Package ID of test APK: `com.xinyv.median.compat`
- Version: `1.4.0-500kb-rc2` (`versionCode 42`)
- Minimum Android: API 26 / Android 8.0
- Target and compile SDK: API 36
- Signature: disposable RSA-3072 test certificate, APK Signature Scheme v2/v3

## What changed from the 180 KB experiment

The browser-facing code once again calls the AndroidX WebKit API shape:
`WebViewFeature.isFeatureSupported`,
`WebViewCompat.addDocumentStartJavaScript`, and `ScriptHandler.remove`.

Rather than package every AndroidX WebKit API and its transitive AndroidX/Kotlin
runtime, the repository vendors the focused Apache-licensed compatibility
source required for document-start injection. It follows the Chromium
support-library boundary protocol used by Android System WebView. The WebView
provider identity is monitored by package/version so the compatibility snapshot
is rebuilt after provider updates.

This removes the prior private `DocumentStartScriptCompat` surface while keeping
the app framework-only and under the KB budget.

## Verification completed

- 40 production Java sources compiled against Android API 36.
- Static security checks and generated userscript JavaScript syntax checks passed.
- R8 release shrinking, optimization and minification completed.
- Single compressed DEX generated.
- APK ZIP integrity and alignment passed.
- Package/version/minSdk/targetSdk inspection passed.
- APK Signature Scheme v2 and v3 verification passed.
- Final DEX retains `WebViewCompat`, `WebViewFeature`, `ScriptHandler`, all three
  Chromium boundary interfaces, the WebView glue class after R8 mapping, and the
  browser's activities/service/provider.
- Glue class name, factory method, and `DOCUMENT_START_SCRIPT:1` feature token
  remain present in final DEX.

## Remaining validation

No Android device or emulator was attached. Before production rollout, test
installation, current stable WebView, OEM WebView providers, user scripts,
downloads, permissions, private mode, multi-tab sessions and long-run stability.
The included APK is test-signed and must not be uploaded to Google Play.
