#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

python3 tools/java_syntax_sanity.py
python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
for p in Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
print('Android XML parse passed')
PY

if rg -n 'addJavascriptInterface|MIXED_CONTENT_ALWAYS_ALLOW|setAllowFileAccess\(true\)|setAllowUniversalAccessFromFileURLs\(true\)|setInstanceFollowRedirects\(true\)' app/src/main; then
  echo 'Unsafe WebView or redirect surface found.' >&2
  exit 1
fi
if rg -n 'median-debug|STOREPASS:-android|versionName=.1\.3\.|Median Browser 1\.2' --glob '!CHANGELOG.md' --glob '!UPGRADE_NOTES.md' --glob '!tools/static_checks.sh' .; then
  echo 'Stale release/debug metadata found.' >&2
  exit 1
fi
rg -q "medianVersionCode = 42" app/build.gradle
rg -q "medianVersionName = '1.4.0-500kb-rc2'" app/build.gradle
rg -q 'targetSdk 36' app/build.gradle
if rg -n '^[[:space:]]*implementation[[:space:]]' app/build.gradle; then
  echo 'Unexpected production runtime dependency found; the focused WebKit slice must remain self-contained.' >&2
  exit 1
fi
rg -Fq 'WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)' app/src/main/java/com/xinyv/median/MainActivity.java
rg -Fq 'WebViewCompat.addDocumentStartJavaScript' app/src/main/java/com/xinyv/median/MainActivity.java
rg -q 'DOCUMENT_START_SCRIPT:1' app/src/main/java/androidx/webkit/WebViewFeature.java
rg -q 'org.chromium.support_lib_glue.SupportLibReflectionUtil' app/src/main/java/androidx/webkit/internal/WebViewGlueCommunicator.java
rg -q 'class WebViewCompat' app/src/main/java/androidx/webkit/WebViewCompat.java
rg -q 'class WebViewFeature' app/src/main/java/androidx/webkit/WebViewFeature.java
rg -q 'interface WebViewProviderFactoryBoundaryInterface' app/src/main/java/org/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface.java
rg -q 'android:allowBackup="false"' app/src/main/AndroidManifest.xml
rg -q 'android:exported="false"' app/src/main/AndroidManifest.xml
rg -q 'EXPECTED_SHA256=20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78' gradlew
rg -Fq 'BuildConfig.APPLICATION_ID + ".offline"' app/src/main/java/com/xinyv/median/OfflineContentProvider.java
rg -Fq 'android:taskAffinity="${applicationId}.private"' app/src/main/AndroidManifest.xml
rg -Fq 'NetworkSecurity.isCredentialHeader(name)' app/src/main/java/com/xinyv/median/MainActivity.java
rg -Fq 'NetworkSecurity.isCredentialHeader(name)' app/src/main/java/com/xinyv/median/AdaptiveDownloadService.java
rg -Fq 'parseContentRange(connection.getHeaderField("Content-Range"))' app/src/main/java/com/xinyv/median/AdaptiveDownloadService.java
rg -Fq 'sameSecureOrigin(pendingPermissionOrigin, webView.getUrl())' app/src/main/java/com/xinyv/median/MainActivity.java
rg -Fq "String(location.hostname||'').toLowerCase()==='median.invalid'" app/src/main/java/com/xinyv/median/UserScriptStore.java
if rg -n 'STOREPASS.*android|KEYPASS.*android|median-debug\.p12|keytool.*-storepass android' --glob '!CHANGELOG.md' --glob '!UPGRADE_NOTES.md' --glob '!tools/static_checks.sh' .; then
  echo 'Weak or auto-generated release signing material found.' >&2
  exit 1
fi
bash -n build.sh tools/build_500kb_apk.sh tools/verify.sh tools/verify_release_tag.sh tools/tests/userscript_js_syntax_test.sh
sh -n gradlew

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" \
  app/src/main/java/com/xinyv/median/NetworkSecurity.java \
  tools/tests/NetworkSecuritySelfTest.java
java -cp "$TMP" com.xinyv.median.NetworkSecuritySelfTest
tools/tests/userscript_js_syntax_test.sh

if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git diff --check
fi
echo 'Static checks passed.'
