# Median Browser 1.4.0 500KB RC2 构建报告

## 目标修正

500 KB 是安装包上限与兼容性预算，不是要求继续维持 180 KB，也不是构建失败条件。本版把剩余空间用于增强 WebView 兼容诊断和安全兜底；构建脚本只报告是否达到 500 KiB 发行目标。

## 成品

- APK：`MedianBrowser-1.4.0-500kb-rc2.apk`
- 包名：`com.xinyv.median.compat`
- versionCode：42
- versionName：`1.4.0-500kb-rc2`
- minSdk：26
- targetSdk：36
- 大小：189,054 字节（约 184.6 KiB）
- 500 KiB 剩余预算：322,946 字节
- 签名：临时测试证书，APK Signature Scheme v2/v3

## 相比 RC1 的兼容性改进

- System WebView 包名、版本与特征快照会在提供方更新后自动刷新。
- 对 WebView glue 加载失败进行稳定分类，不再静默吞掉所有异常。
- 捕获反射、调用、运行时与 LinkageError，失败时保持高权限用户脚本关闭。
- 兼容少量 OEM WebView 使用未版本化 `DOCUMENT_START_SCRIPT` 特征名的情况。
- document-start 注册强制在 UI 线程执行。
- allowed-origin 规则执行空值、scheme、host、路径、查询、fragment 与用户信息校验。
- ScriptHandler 移除具备幂等保护，可应对 WebView 提供方重启。
- 关于页提供可复制的 WebView 兼容诊断。
- 新增本地无网络顺序自测，验证 document-start 是否确实早于页面脚本执行。
- 自测失败或功能不受支持时，Median 继续只运行无原生权限脚本，高权限 API 保持关闭。

## 已执行验证

- Java 语法检查：40 个文件通过。
- Android XML 解析通过。
- NetworkSecuritySelfTest 通过。
- 生成的用户脚本 JavaScript 语法测试通过。
- Java 17 编译通过。
- R8 release 收缩通过。
- 单 DEX 打包通过。
- ZIP 完整性检查通过。
- 包名、版本、minSdk、targetSdk 检查通过。
- v2/v3 签名验证通过。
- 最终 DEX 包含兼容诊断和 document-start 自测入口。

## 尚未完成

当前环境没有实体 Android 设备。因此仍需在 Android 8–16，以及 Chrome WebView、Android System WebView 和主要国产 ROM WebView 上运行应用内自测及完整浏览回归。测试 APK 不可直接用于 Google Play 正式发布；正式版本必须使用长期上传密钥重新签名并生成 AAB。
